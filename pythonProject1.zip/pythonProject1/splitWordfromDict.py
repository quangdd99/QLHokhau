# open word dict, create input
f = open('eng_dict', 'r')
wordDict = f.read().split()
s = input("Chuoi ky tu can tach : ")

# create variable : queue to store word processed, so on...
queue = []
queue.append("")

# process the queue
while queue != []:
    demo = queue.pop(0)
    unprocess = s[len(demo) - demo.count(" "):]
    list2_word = []
    while len(unprocess) > 0:
        for word in wordDict:
            if word[0] == unprocess[0]:
                list2_word.append(word)
        if list2_word.count(unprocess) > 0:
            queue.append(demo + " " + unprocess)
        unprocess = unprocess[:-1]
    if len(demo) - demo.count(" ") == len(s):
        print(demo)