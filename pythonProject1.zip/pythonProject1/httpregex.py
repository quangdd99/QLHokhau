import re
x = r"^(http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/)[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$"
url = input("nhap vao url can regex : ")
list_match = re.fullmatch(x,url)
print("danh sach cac dia chi la url :", list_match)