package model;
/**
 * 
 * @Author: Lương Ngọc Thuyết
 * MSSV:20183994
 */
public class Information_TamTru {
	private String name;
	private String birth;
	private String cmnd;
	private String dctt;
	private String nohn;
	private String from;
	private String to;
	
	public Information_TamTru(String name, String birth, String cmnd, String dctt, String nohn, String from,
			String to) {
		super();
		this.name = name;
		this.birth = birth;
		this.cmnd = cmnd;
		this.dctt = dctt;
		this.nohn = nohn;
		this.from = from;
		this.to = to;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBirth() {
		return birth;
	}
	public void setBirth(String birth) {
		this.birth = birth;
	}
	public String getCmnd() {
		return cmnd;
	}
	public void setCmnd(String cmnd) {
		this.cmnd = cmnd;
	}
	public String getDctt() {
		return dctt;
	}
	public void setDctt(String dctt) {
		this.dctt = dctt;
	}
	public String getNohn() {
		return nohn;
	}
	public void setNohn(String nohn) {
		this.nohn = nohn;
	}
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
}
