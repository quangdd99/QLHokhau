
package model;

import java.sql.Date;

public class NhatKyThayDoi {
    private int stt;
    private Date thoiGian;
    private String noiDung;

    public NhatKyThayDoi() {
    }

    public NhatKyThayDoi(int stt, Date thoiGian, String noiDung) {
        this.stt = stt;
        this.thoiGian = thoiGian;
        this.noiDung = noiDung;
    }

    public int getStt() {
        return stt;
    }

    public void setStt(int stt) {
        this.stt = stt;
    }

    public Date getThoiGian() {
        return thoiGian;
    }

    public void setThoiGian(Date thoiGian) {
        this.thoiGian = thoiGian;
    }

    public String getNoiDung() {
        return noiDung;
    }

    public void setNoiDung(String noiDung) {
        this.noiDung = noiDung;
    }
    
}
