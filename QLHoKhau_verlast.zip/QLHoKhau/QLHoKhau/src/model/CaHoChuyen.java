
package model;

import java.sql.Date;


public class CaHoChuyen {
    private int id;
    private Date ngayChuyen;
    private String noiChuyenDen;
    private String liDo;
    private String soHk;

    public CaHoChuyen() {
    }

    public CaHoChuyen(int id, Date ngayChuyen, String noiChuyenDen, String liDo, String soHk) {
        this.id = id;
        this.ngayChuyen = ngayChuyen;
        this.noiChuyenDen = noiChuyenDen;
        this.liDo = liDo;
        this.soHk = soHk;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getNgayChuyen() {
        return ngayChuyen;
    }

    public void setNgayChuyen(Date ngayChuyen) {
        this.ngayChuyen = ngayChuyen;
    }

    public String getNoiChuyenDen() {
        return noiChuyenDen;
    }

    public void setNoiChuyenDen(String noiChuyenDen) {
        this.noiChuyenDen = noiChuyenDen;
    }

    public String getLiDo() {
        return liDo;
    }

    public void setLiDo(String liDo) {
        this.liDo = liDo;
    }

    public String getSoHk() {
        return soHk;
    }

    public void setSoHk(String soHk) {
        this.soHk = soHk;
    }
    
}
