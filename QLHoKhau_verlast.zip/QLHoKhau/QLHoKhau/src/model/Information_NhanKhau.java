package model;
/**
 * 
 * @Author: Lương Ngọc Thuyết
 * MSSV:20183994
 */
public class Information_NhanKhau {
	private String	id;
	private String	cmnd;
	private String	name;
	private String	bi_danh;
	private String	gender;
	private String	quan_he_chu_ho;
	private String	birth;
	private String	noi_sinh;
	private String	address;
	private String	dan_toc;
	private String	nghe_nghiep;
	private String	noi_lam_viec;
	private String	status;
	private String	ngay_cap;
	private String	noi_cap;
	private String	ngay_dang_ki;
	private String	dia_chi_truoc;
	private String	soHK;
	
// Contrustor cho HoSoNhanKhau
	public Information_NhanKhau(String id,  String name, String bi_danh, String gender,
			String quan_he_chu_ho, String birth, String noi_sinh, String address, String dan_toc, String nghe_nghiep,
			String noi_lam_viec,String cmnd, String ngay_cap, String noi_cap, String ngay_dang_ki,
			String dia_chi_truoc, String soHK,String status) {
		this.id = id;
		this.cmnd = cmnd;
		this.name = name;
		this.bi_danh = bi_danh;
		this.gender = gender;
		this.quan_he_chu_ho = quan_he_chu_ho;
		this.birth = birth;
		this.noi_sinh = noi_sinh;
		this.address = address;
		this.dan_toc = dan_toc;
		this.nghe_nghiep = nghe_nghiep;
		this.noi_lam_viec = noi_lam_viec;
		this.status = status;
		this.ngay_cap = ngay_cap;
		this.noi_cap = noi_cap;
		this.ngay_dang_ki = ngay_dang_ki;
		this.dia_chi_truoc = dia_chi_truoc;
		this.soHK = soHK;
	}
	
	// 
	public Information_NhanKhau(Information_NhanKhau inf) {
		
	}
	
// Getter Setter All 
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCmnd() {
		return cmnd;
	}
	public void setCmnd(String cmnd) {
		this.cmnd = cmnd;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBi_danh() {
		return bi_danh;
	}
	public void setBi_danh(String bi_danh) {
		this.bi_danh = bi_danh;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getQuan_he_chu_ho() {
		return quan_he_chu_ho;
	}
	public void setQuan_he_chu_ho(String quan_he_chu_ho) {
		this.quan_he_chu_ho = quan_he_chu_ho;
	}
	public String getBirth() {
		return birth;
	}
	public void setBirth(String birth) {
		this.birth = birth;
	}
	public String getNoi_sinh() {
		return noi_sinh;
	}
	public void setNoi_sinh(String noi_sinh) {
		this.noi_sinh = noi_sinh;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDan_toc() {
		return dan_toc;
	}
	public void setDan_toc(String dan_toc) {
		this.dan_toc = dan_toc;
	}
	public String getNghe_nghiep() {
		return nghe_nghiep;
	}
	public void setNghe_nghiep(String nghe_nghiep) {
		this.nghe_nghiep = nghe_nghiep;
	}
	public String getNoi_lam_viec() {
		return noi_lam_viec;
	}
	public void setNoi_lam_viec(String noi_lam_viec) {
		this.noi_lam_viec = noi_lam_viec;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getNgay_cap() {
		return ngay_cap;
	}
	public void setNgay_cap(String ngay_cap) {
		this.ngay_cap = ngay_cap;
	}
	public String getNoi_cap() {
		return noi_cap;
	}
	public void setNoi_cap(String noi_cap) {
		this.noi_cap = noi_cap;
	}
	public String getNgay_dang_ki() {
		return ngay_dang_ki;
	}
	public void setNgay_dang_ki(String ngay_dang_ki) {
		this.ngay_dang_ki = ngay_dang_ki;
	}
	public String getDia_chi_truoc() {
		return dia_chi_truoc;
	}
	public void setDia_chi_truoc(String dia_chi_truoc) {
		this.dia_chi_truoc = dia_chi_truoc;
	}
	public String getSoHK() {
		return soHK;
	}
	public void setSoHK(String soHK) {
		this.soHK = soHK;
	}
}
