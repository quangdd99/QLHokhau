
package model;

import java.sql.Date;


public class NhanKhauChuyen {
    private int id;
    private Date ngayChuyen;
    private String noiDen;
    private String liDo;
    private String cmnd;

    public NhanKhauChuyen() {
    }

    public NhanKhauChuyen(int id, Date ngayChuyen, String noiDen, String liDo, String cmnd) {
        this.id = id;
        this.ngayChuyen = ngayChuyen;
        this.noiDen = noiDen;
        this.liDo = liDo;
        this.cmnd = cmnd;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getNgayChuyen() {
        return ngayChuyen;
    }

    public void setNgayChuyen(Date ngayChuyen) {
        this.ngayChuyen = ngayChuyen;
    }

    public String getNoiDen() {
        return noiDen;
    }

    public void setNoiDen(String noiDen) {
        this.noiDen = noiDen;
    }

    public String getLiDo() {
        return liDo;
    }

    public void setLiDo(String liDo) {
        this.liDo = liDo;
    }

    public String getCmnd() {
        return cmnd;
    }

    public void setCmnd(String cmnd) {
        this.cmnd = cmnd;
    }
    
}
