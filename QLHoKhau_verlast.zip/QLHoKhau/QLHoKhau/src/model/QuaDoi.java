
package model;

import java.sql.Date;


public class QuaDoi {
    private int id;
    private Date ngayMat;
    private String noiMat;
    private String nguyenNhan;
    private String noiCapGiay;
    private NhanKhau cmnd;

    public QuaDoi() {
    }

    public QuaDoi(int id, Date ngayMat, String noiMat, String nguyenNhan, String noiCapGiay, NhanKhau cmnd) {
        this.id = id;
        this.ngayMat = ngayMat;
        this.noiMat = noiMat;
        this.nguyenNhan = nguyenNhan;
        this.noiCapGiay = noiCapGiay;
        this.cmnd = cmnd;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getNgayMat() {
        return ngayMat;
    }

    public void setNgayMat(Date ngayMat) {
        this.ngayMat = ngayMat;
    }

    public String getNoiMat() {
        return noiMat;
    }

    public void setNoiMat(String noiMat) {
        this.noiMat = noiMat;
    }

    public String getNguyenNhan() {
        return nguyenNhan;
    }

    public void setNguyenNhan(String nguyenNhan) {
        this.nguyenNhan = nguyenNhan;
    }

    public String getNoiCapGiay() {
        return noiCapGiay;
    }

    public void setNoiCapGiay(String noiCapGiay) {
        this.noiCapGiay = noiCapGiay;
    }

    public NhanKhau getCmnd() {
        return cmnd;
    }

    public void setCmnd(NhanKhau cmnd) {
        this.cmnd = cmnd;
    }
    
}
