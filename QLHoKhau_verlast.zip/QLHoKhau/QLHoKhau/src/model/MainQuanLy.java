package model;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import common.Config;
import javafx.scene.Scene;
/**
 * 
 * @Author: Lương Ngọc Thuyết
 * MSSV:20183994
 */
public class MainQuanLy extends Config {
	public static ResultSet resultSet;
	public static Statement statement;
	public static Scene scene_ThongKe;
	public static void setStatement_ThongKe() {
		try {
			Class.forName(DRIVER);
			statement=DriverManager.getConnection(URL, USERNAME, PASSWORD).createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void setResultSet_NhanKhau() {
		try {
			resultSet=statement.executeQuery("SELECT * FROM ho_khau.nhan_khau");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public static void setResultSet_TamTru() {
		try {
			resultSet=statement.executeQuery("SELECT * FROM ho_khau.tam_tru");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public static void setResultSet_TamVang() {
		try {
			resultSet=statement.executeQuery("SELECT * FROM ho_khau.nhan_khau INNER JOIN ho_khau.tam_vang ON ho_khau.nhan_khau.cmnd=ho_khau.tam_vang.nhan_khau_cmnd");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
