
package model;


public class SoHoKhau {
    private int id;
    private String soHk;
    private String chuHo;
    private String soNha;
    private String phuong;
    private String duongPho;
    private String quan;
    private int status;

    public SoHoKhau() {
    }

    public SoHoKhau(int id, String soHk, String chuHo, String soNha, String phuong, String duongPho, String quan, int status) {
        this.id = id;
        this.soHk = soHk;
        this.chuHo = chuHo;
        this.soNha = soNha;
        this.phuong = phuong;
        this.duongPho = duongPho;
        this.quan = quan;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "SoHoKhau{" + "id=" + id + ", soHk=" + soHk + ", chuHo=" + chuHo + ", soNha=" + soNha + ", phuong=" + phuong + ", duongPho=" + duongPho + ", quan=" + quan + ", status=" + status + '}';
    }

    public String getSoHk() {
        return soHk;
    }

    public void setSoHk(String soHk) {
        this.soHk = soHk;
    }

    public String getChuHo() {
        return chuHo;
    }

    public void setChuHo(String chuHo) {
        this.chuHo = chuHo;
    }

    public String getSoNha() {
        return soNha;
    }

    public void setSoNha(String soNha) {
        this.soNha = soNha;
    }

    public String getPhuong() {
        return phuong;
    }

    public void setPhuong(String phuong) {
        this.phuong = phuong;
    }

    public String getDuongPho() {
        return duongPho;
    }

    public void setDuongPho(String duongPho) {
        this.duongPho = duongPho;
    }

    public String getQuan() {
        return quan;
    }

    public void setQuan(String quan) {
        this.quan = quan;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public void add(SoHoKhau sohokhau) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
