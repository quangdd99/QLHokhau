/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Date;
import java.time.LocalDate;

/**
 *
 * @author LTC
 */
public class TamTru {
    private int id;
    private String ten;
    private Date ngaySinh;
    private String cmnd;
    private Date ngayCap;
    private String noiCap;
    private String dcThuongTru;
    private String dcHienNay;
    private Date tgTu;
    private Date tgHet;

    public TamTru() {
    }

    public TamTru(int id, String ten, Date ngaySinh, String cmnd, Date ngayCap, String noiCap, String dcThuongTru, String dcHienNay, Date tgTu, Date tgHet) {
        this.id = id;
        this.ten = ten;
        this.ngaySinh = ngaySinh;
        this.cmnd = cmnd;
        this.ngayCap = ngayCap;
        this.noiCap = noiCap;
        this.dcThuongTru = dcThuongTru;
        this.dcHienNay = dcHienNay;
        this.tgTu = tgTu;
        this.tgHet = tgHet;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public Date getNgaySinh() {
        return ngaySinh;
    }

    public void setNgaySinh(Date ngaySinh) {
        this.ngaySinh = ngaySinh;
    }

    public String getCmnd() {
        return cmnd;
    }

    public void setCmnd(String cmnd) {
        this.cmnd = cmnd;
    }

    public Date getNgayCap() {
        return ngayCap;
    }

    public void setNgayCap(Date ngayCap) {
        this.ngayCap = ngayCap;
    }

    public String getNoiCap() {
        return noiCap;
    }

    public void setNoiCap(String noiCap) {
        this.noiCap = noiCap;
    }

    public String getDcThuongTru() {
        return dcThuongTru;
    }

    public void setDcThuongTru(String dcThuongTru) {
        this.dcThuongTru = dcThuongTru;
    }

    public String getDcHienNay() {
        return dcHienNay;
    }

    public void setDcHienNay(String dcHienNay) {
        this.dcHienNay = dcHienNay;
    }

    public Date getTgTu() {
        return tgTu;
    }

    public void setTgTu(Date tgTu) {
        this.tgTu = tgTu;
    }

    public Date getTgHet() {
        return tgHet;
    }

    public void setTgHet(Date tgHet) {
        this.tgHet = tgHet;
    }

    @Override
    public String toString() {
        return "TamTru{" + "id=" + id + ", ten=" + ten + ", ngaySinh=" + ngaySinh + ", cmnd=" + cmnd + ", ngayCap=" + ngayCap + ", noiCap=" + noiCap + ", dcThuongTru=" + dcThuongTru + ", dcHienNay=" + dcHienNay + ", tgTu=" + tgTu + ", tgHet=" + tgHet + '}';
    }
    

    
}
