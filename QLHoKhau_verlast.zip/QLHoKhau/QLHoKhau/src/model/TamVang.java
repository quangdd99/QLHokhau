
package model;

import java.sql.Date;


public class TamVang {
    private int id;
    private String noiDen;
    private Date tgTu;
    private Date tgHet;
    private String liDo;
    private NhanKhau cmnd;

    public TamVang() {
    }

    public TamVang(int id, String noiDen, Date tgTu, Date tgHet, String liDo, NhanKhau cmnd) {
        this.id = id;
        this.noiDen = noiDen;
        this.tgTu = tgTu;
        this.tgHet = tgHet;
        this.liDo = liDo;
        this.cmnd = cmnd;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNoiDen() {
        return noiDen;
    }

    public void setNoiDen(String noiDen) {
        this.noiDen = noiDen;
    }

    public Date getTgTu() {
        return tgTu;
    }

    public void setTgTu(Date tgTu) {
        this.tgTu = tgTu;
    }

    public Date getTgHet() {
        return tgHet;
    }

    public void setTgHet(Date tgHet) {
        this.tgHet = tgHet;
    }

    public String getLiDo() {
        return liDo;
    }

    public void setLiDo(String liDo) {
        this.liDo = liDo;
    }

    public NhanKhau getCmnd() {
        return cmnd;
    }

    public void setCmnd(NhanKhau cmnd) {
        this.cmnd = cmnd;
    }
    
}
