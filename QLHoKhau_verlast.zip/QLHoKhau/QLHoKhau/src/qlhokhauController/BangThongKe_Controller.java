package qlhokhauController;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import model.Information_NhanKhau;
import model.MainQuanLy;

/**
 * 
 * @Author: Lương Ngọc Thuyết
 * MSSV:20183994
 */
public class BangThongKe_Controller  implements Initializable{
	@FXML
	Button back_Button_BangThongKe;
	
	@FXML
	TableView<Information_NhanKhau> thongKe_Table;
	
	@FXML
	TableColumn<Information_NhanKhau, String> thongKe_Table_Name;
	
	@FXML
	TableColumn<Information_NhanKhau, String> thongKe_Table_CMND;
	
	@FXML
	TableColumn<Information_NhanKhau, String> thongKe_Table_Gender;
	
	@FXML
	TableColumn<Information_NhanKhau, String> thongKe_Table_Birth;
	
	@FXML
	TableColumn<Information_NhanKhau, String> thongKe_Table_Address;
	
	@FXML
	TableColumn<Information_NhanKhau, String> thongKe_Table_SoHK;
	
	@FXML
	Label label_Number;
	public static boolean kt_SHK=false;
	public static Scene scene_ThongKe_SHK;
	ObservableList<Information_NhanKhau> list_SoHK=FXCollections.observableArrayList();
	
	public void setListBangThongKe(ObservableList<Information_NhanKhau> list) {
		thongKe_Table.setItems(list);
	}
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		thongKe_Table_Name.setCellValueFactory(new PropertyValueFactory<Information_NhanKhau, String>("name"));
		thongKe_Table_CMND.setCellValueFactory(new PropertyValueFactory<Information_NhanKhau, String>("cmnd"));
		thongKe_Table_Gender.setCellValueFactory(new PropertyValueFactory<Information_NhanKhau, String>("gender"));
		thongKe_Table_Birth.setCellValueFactory(new PropertyValueFactory<Information_NhanKhau, String>("birth"));
		thongKe_Table_Address.setCellValueFactory(new PropertyValueFactory<Information_NhanKhau, String>("address"));
		thongKe_Table_SoHK.setCellValueFactory(new PropertyValueFactory<Information_NhanKhau, String>("soHK"));
		thongKe_Table.setRowFactory(r->{
			TableRow<Information_NhanKhau> row = new TableRow<Information_NhanKhau>();
			row.setOnMouseClicked(event_SHK->{
			// Action double click left mouse
				if (event_SHK.getClickCount()==2 && row.isEmpty()==false && event_SHK.getButton()==MouseButton.PRIMARY)
				{
					Stage stage = (Stage) ((Node) event_SHK.getSource()).getScene().getWindow();
					FXMLLoader loader_SoHoKhau=new FXMLLoader();
					loader_SoHoKhau.setLocation(getClass().getResource("SoHoKhau.fxml"));
					Pane root = null; 
					try {
						root = loader_SoHoKhau.load();
					} catch (IOException e) {
						e.printStackTrace();
					}
					Scene scene =new Scene(root);
					SoHoKhau_Controller soHoKhau_Controller=loader_SoHoKhau.getController();
					soHoKhau_Controller.setSoHoKhau(thongKe_Table.getSelectionModel().getSelectedItem());
					if (thongKe_Table.getSelectionModel().getSelectedItem().getStatus().equals("2")) {
						try {
							String note=new String();
							MainQuanLy.setResultSet_TamVang();
							while (MainQuanLy.resultSet.next()) {
									if (MainQuanLy.resultSet.getString(24).equals(thongKe_Table.getSelectionModel().getSelectedItem().getCmnd())){
										note=note.concat("TẠM VẮNG \n");
										note=note.concat("Chuyển đến : ");
										note=note.concat(MainQuanLy.resultSet.getString(20));
										note=note.concat("\n");
										note=note.concat("Lý do : ");
										note=note.concat(MainQuanLy.resultSet.getString(23));
										note=note.concat("\n");
										note=note.concat("Thời gian từ : ");
										note=note.concat(MainQuanLy.resultSet.getString(21));
										note=note.concat(" đến ");
										note=note.concat(MainQuanLy.resultSet.getString(22));
										soHoKhau_Controller.setGhiChu(note);
								}
									note="";
							}
							
							MainQuanLy.resultSet.close();
						} catch (SQLException e) {
							e.printStackTrace();
						}
					}
					stage.setTitle("THÔNG TIN NHÂN KHẨU");
					stage.setScene(scene);
					stage.setResizable(false);
				} else
			// Action double click left mouse
				if (event_SHK.getButton()==MouseButton.SECONDARY && row.isEmpty()==false) {
					Information_NhanKhau nhankhau=thongKe_Table.getSelectionModel().getSelectedItem();
					MenuItem item=new MenuItem("Xem thông tin hộ khẩu");
					item.setOnAction(e->{
						kt_SHK=true;
						try {
							
							list_SoHK.clear();
							MainQuanLy.setResultSet_NhanKhau();
							while (MainQuanLy.resultSet.next())
								if (nhankhau.getSoHK().equals(MainQuanLy.resultSet.getString(17))) {
									list_SoHK.add(new Information_NhanKhau(
											MainQuanLy.resultSet.getString(1),MainQuanLy.resultSet.getString(2), MainQuanLy.resultSet.getString(3), 
											MainQuanLy.resultSet.getString(4), MainQuanLy.resultSet.getString(5), MainQuanLy.resultSet.getString(6),
											MainQuanLy.resultSet.getString(7), MainQuanLy.resultSet.getString(8), MainQuanLy.resultSet.getString(9),
											MainQuanLy.resultSet.getString(10), MainQuanLy.resultSet.getString(11), MainQuanLy.resultSet.getString(12),
											MainQuanLy.resultSet.getString(13), MainQuanLy.resultSet.getString(14), MainQuanLy.resultSet.getString(15),
											MainQuanLy.resultSet.getString(16), MainQuanLy.resultSet.getString(17), MainQuanLy.resultSet.getString(18)));
								}
						//Create BangThongKe theo SoHoKhau
							Stage stage = (Stage) ((Node) event_SHK.getSource()).getScene().getWindow();
							FXMLLoader loader_BangThongKe=new FXMLLoader();
							loader_BangThongKe.setLocation(getClass().getResource("BangThongKe.fxml"));
							Pane root=null;
							try {
								root = loader_BangThongKe.load();
							} catch (IOException e1) {
								e1.printStackTrace();
							}
							Scene scene=new Scene(root);
							scene_ThongKe_SHK=scene;
					     	BangThongKe_Controller bangThongKe_Controller=loader_BangThongKe.getController();
						    bangThongKe_Controller.setListBangThongKe(list_SoHK);
						    bangThongKe_Controller.label_Number.setText(Integer.toString(list_SoHK.size()));
							stage.setScene(scene);
							stage.setTitle("DANH SÁCH THỐNG KÊ");
							stage.setResizable(false);
							
							MainQuanLy.resultSet.close();//close ResultSet
						} catch (SQLException e1) {
							e1.printStackTrace();
						}
					});
					
					ContextMenu menu=new ContextMenu();
					menu.getItems().add(item);
					row.setOnContextMenuRequested(e->{
						menu.show(row, e.getScreenX(), e.getScreenY());
					});
				}
			});
			return row;
		});
	}
	
// Action Button Back_BangThongKe
	public void goBack_ThongKe(ActionEvent e) throws IOException {
		Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
		if (kt_SHK==true) {
			stage.setScene(ThongKe_Controller.scene_BangThongKe);
			stage.setTitle("DANH SÁCH THỐNG KÊ");
			kt_SHK=false;
		} else {
			stage.setScene(MainQuanLy.scene_ThongKe);
			stage.setTitle("THỐNG KÊ"); 
		}
		stage.setResizable(false);
	}
}
