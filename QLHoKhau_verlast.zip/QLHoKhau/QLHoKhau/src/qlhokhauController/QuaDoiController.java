/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package qlhokhauController;

import dao.CheckNhanKhauDAO;
import dao.NhatKyDAO;
import dao.QuaDoiDAO;
import dao.ThongBaoDAO;
import java.io.IOException;
import java.net.URL;
import java.text.ParseException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author hohun
 */
public class QuaDoiController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    TextField hoTen;
    @FXML
    TextField cmnd;
    @FXML
    TextField ngayMat;
    @FXML
    TextField noiMat;
    @FXML
    TextField noiCap;
    @FXML
    TextArea lyDo;
    
    @FXML
    private void actionOK(ActionEvent event) throws IOException, ParseException {
        String ht = hoTen.getText();
        String cm = cmnd.getText();
        String ngm = ngayMat.getText();
        String nm = noiMat.getText();
        String nc = noiCap.getText();
        String ld = lyDo.getText();
        ThongBaoDAO e = new ThongBaoDAO();
        if ("".equals(ht) || "".equals(cm) || "".equals(ngm) || "".equals(nm) || "".equals(ld) || "".equals(nc)){
            e.showErrorText("Thông tin còn thiếu!");
        }
        else{
            CheckNhanKhauDAO ck = new CheckNhanKhauDAO();
            if (!ck.check(ht, cm)){
                e.showErrorText("Thông tin nhân khẩu không đúng!");
            }
            else{
                QuaDoiDAO q = new QuaDoiDAO();
                q.quaDoi(cm, ngm, nm, nc, ld);
                q.danhDau(cm);
                String noiDung = "Qua đời: "+ht +" cmnd: "+cm+" Ngày mất: "+ngm+" Nơi mất: "+nm+" Nguyên nhân qua đời: "+ld;
                NhatKyDAO k = new NhatKyDAO();
                k.addNhatKy(noiDung);
                e.showSuccessText("Thay đổi thành công!");
                hoTen.clear();
                cmnd.clear();
                ngayMat.clear();
                noiMat.clear();
                noiCap.clear();
                lyDo.clear();
            }
        }
    }
    @FXML
    private void actionTroLai(ActionEvent event) throws IOException {
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("Sua.fxml"));
        Parent sampleParent = loader.load();
        Scene scene = new Scene(sampleParent);
        stage.setScene(scene);
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
