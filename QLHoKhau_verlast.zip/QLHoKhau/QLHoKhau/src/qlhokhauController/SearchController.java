
package qlhokhauController;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class SearchController{
        @FXML
        public void Key_Search(ActionEvent event) throws IOException{
           
            Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("KeySearch.fxml"));
            Parent sampleParent = loader.load();
            Scene scene = new Scene(sampleParent);
            stage.setTitle("Tìm kiếm theo khóa");
            stage.setScene(scene);   
            
        }
        @FXML
        public void Action_Search(ActionEvent event) throws IOException{
           
            
            Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("ActionSearch.fxml"));
            Parent sampleParent = loader.load();
            Scene scene = new Scene(sampleParent);
            stage.setTitle("Tìm kiếm theo thay đổi hoạt dộng nhân khẩu");
            stage.setScene(scene);   
            
        }
        
        public void goBack(ActionEvent event) throws IOException{
           
            
            Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("menu.fxml"));
            Parent sampleParent = loader.load();
            Scene scene = new Scene(sampleParent);
            stage.setScene(scene);   
            
        }
        
}
