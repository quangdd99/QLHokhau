/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package qlhokhauController;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;
import model.MainQuanLy;

/**
 * FXML Controller class
 *
 * @author hohun
 */
public class MenuController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private TextField viewUserName;
    @FXML
    private TextArea inforText;
    
    
    @FXML
    public void handleButtonSignOut(ActionEvent event) throws IOException{
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("SignIn.fxml"));
        Parent sampleParent = loader.load();
        Scene scene = new Scene(sampleParent);
        stage.setScene(scene);
    }
    
    @FXML
    public void handleButtonTimKiem(ActionEvent event) throws IOException{
        
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("Search.fxml"));
        Parent sampleParent = loader.load();
        Scene scene = new Scene(sampleParent);
        stage.setScene(scene);         
    }
    @FXML
    public void handleButtonThongKe(ActionEvent event) throws IOException {
    	 MainQuanLy.setStatement_ThongKe();
    	 Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
         FXMLLoader loader = new FXMLLoader();
         loader.setLocation(getClass().getResource("ThongKe.fxml"));
         Parent sampleParent = loader.load();
         Scene scene = new Scene(sampleParent);
         MainQuanLy.scene_ThongKe=scene; 
         stage.setScene(scene);         
    }
    @FXML
    public void handleButtonLichSu(ActionEvent event){
        
    }
    @FXML
    public void handleButtonThemNK(ActionEvent event){
        
    }
    @FXML
    public void handleButtonThemHK(ActionEvent event){
        
    }
    @FXML
    public void handleButtonSua(ActionEvent event) throws IOException{
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("Sua.fxml"));
        Parent sampleParent = loader.load();
        Scene scene = new Scene(sampleParent);
        stage.setTitle("Sá»­a");
        stage.setScene(scene);
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        viewUserName.setText("Admin");
        inforText.setText("Pháº§n má»�m Ä‘Æ°á»£c cáº­p nháº­t má»›i nháº¥t ngÃ y 20/12/2019. Pháº§n má»�m Ä‘Æ°á»£c thiáº¿t káº¿ bá»Ÿi nhÃ³m 4. Má»�i tháº¯c máº¯c xin gá»­i vá»� email: OOP.nhom4@gmail.com");
        // TODO
    }    
    
}
