/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package qlhokhauController;

import dao.CaHoChuyenDAO;
import dao.CheckHoKhauDAO;
import dao.NhatKyDAO;
import dao.ThongBaoDAO;
import java.io.IOException;
import java.net.URL;
import java.text.ParseException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author hohun
 */
public class CaHoChuyenController implements Initializable {

   
    @FXML
    TextField chuHo;
    @FXML
    TextField shk;
    @FXML
    TextField thoiGian;
    @FXML
    TextField noiDen;
    @FXML
    TextArea lyDo;
    @FXML
    private void actionOK(ActionEvent event) throws IOException, ParseException {
        String ch = chuHo.getText();
        String hk = shk.getText();
        String tg = thoiGian.getText();
        String nd = noiDen.getText();
        String ld = lyDo.getText();
        
        ThongBaoDAO e = new ThongBaoDAO();
        if ("".equals(ch) || "".equals(hk) || "".equals(tg) || "".equals(nd) || "".equals(ld) ){
            e.showErrorText("Thông tin còn thiếu!");
        }
        else{
            CheckHoKhauDAO ck = new CheckHoKhauDAO();
            if (!ck.check(ch, hk)){
                e.showErrorText("Thông tin chủ hộ không đúng!");
            }
            else{
                CaHoChuyenDAO c = new CaHoChuyenDAO();
                c.caHoChuyen(hk, tg, nd, ld);
                c.danhDau(1,hk);
                c.danhDau(2, hk);
        
                String noiDung = "Cả hộ chuyển: Số hộ khẩu "+hk+" chủ hộ: "+ch+" Ngày "+tg+" .Nơi đến: "+nd+" \n Lý do:"+ld;
                NhatKyDAO k = new NhatKyDAO();
                k.addNhatKy(noiDung);
                e.showSuccessText("Thay đổi thành công!");
                chuHo.clear();
                shk.clear();
                thoiGian.clear();
                noiDen.clear();
                lyDo.clear();
            }
        }
    }
    @FXML
    private void actionTroLai(ActionEvent event) throws IOException {
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("Sua.fxml"));
        Parent sampleParent = loader.load();
        Scene scene = new Scene(sampleParent);
        stage.setScene(scene);
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
