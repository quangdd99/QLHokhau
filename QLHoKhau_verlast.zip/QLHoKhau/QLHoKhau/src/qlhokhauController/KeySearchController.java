package qlhokhauController;

import dao.TimKiemNhanKhauDao;

import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.NhanKhau;

public class KeySearchController implements Initializable {

    @FXML
    private TextField key1;
    @FXML
    private TableView<NhanKhau> table1;
    @FXML
    private TableColumn<NhanKhau, Integer> id;
    @FXML
    private TableColumn<NhanKhau, String> ten;
    @FXML
    private TableColumn<NhanKhau, String> bidanh;
    @FXML
    private TableColumn<NhanKhau, String> gioitinh;
    @FXML
    private TableColumn<NhanKhau, String> quanhe;
    @FXML
    private TableColumn<NhanKhau, Date> ngaysinh;
    @FXML
    private TableColumn<NhanKhau, String> noisinh;
    @FXML
    private TableColumn<NhanKhau, String> quequan;
    @FXML
    private TableColumn<NhanKhau, String> dantoc;
    @FXML
    private TableColumn<NhanKhau, String> nghenghiep;
    @FXML
    private TableColumn<NhanKhau, String> cmnd;
    @FXML
    private TableColumn<NhanKhau, String> ngaycap;
    @FXML
    private TableColumn<NhanKhau, String> noicap;
    @FXML
    private TableColumn<NhanKhau, String> sohk;
    @FXML
    private TableColumn<NhanKhau, String> tt;

    private ObservableList<NhanKhau> nhanKhauList;

    @FXML
    public void getListNhanKhau(ActionEvent event) throws IOException {
        String key = key1.getText();
        TimKiemNhanKhauDao nhanKhauDao = new TimKiemNhanKhauDao();
        nhanKhauList = FXCollections.observableArrayList(
                nhanKhauDao.getListNhanKhau(key)
        );
        id.setCellValueFactory(new PropertyValueFactory<>("id"));
        ten.setCellValueFactory(new PropertyValueFactory<>("ten"));
        bidanh.setCellValueFactory(new PropertyValueFactory<>("biDanh"));
        gioitinh.setCellValueFactory(new PropertyValueFactory<>("gioiTinh"));
        quanhe.setCellValueFactory(new PropertyValueFactory<>("quanHeChuHo"));
        ngaysinh.setCellValueFactory(new PropertyValueFactory<>("ngaySinh"));
        noisinh.setCellValueFactory(new PropertyValueFactory<>("noiSinh"));
        quequan.setCellValueFactory(new PropertyValueFactory<>("queQuan"));
        dantoc.setCellValueFactory(new PropertyValueFactory<>("danToc"));
        nghenghiep.setCellValueFactory(new PropertyValueFactory<>("ngheNghiep"));
        
        cmnd.setCellValueFactory(new PropertyValueFactory<>("cmnd"));
        ngaycap.setCellValueFactory(new PropertyValueFactory<>("ngayCap"));
        noicap.setCellValueFactory(new PropertyValueFactory<>("noiCap"));
        sohk.setCellValueFactory(new PropertyValueFactory<>("soHk"));
        tt.setCellValueFactory(new PropertyValueFactory<>("status"));
        
        table1.setItems(nhanKhauList);
    }

    @FXML
    public void Goback1(ActionEvent event) throws IOException{
        
            
            
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("Search.fxml"));
        Parent sampleParent = loader.load();
        Scene scene = new Scene(sampleParent);
        stage.setTitle("Tìm kiếm");
        stage.setScene(scene);   
            
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }
}
