package qlhokhauController;

import java.io.IOException;
import java.time.LocalDate;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Information_NhanKhau;
/**
 * 
 * @Author: Lương Ngọc Thuyết
 * MSSV:20183994
 */
public class SoHoKhau_Controller{
	@FXML
	Button back_Button_SoHoKhau;
	
	@FXML
	TextField textField_QHCH;
	
	@FXML
	TextField textField_Name;
	
	@FXML
	TextField textField_NameOther;
	
	@FXML
	TextField textField_QueQuan;
	
	@FXML
	TextField textField_DanToc;
	
	@FXML
	TextField textField_TonGiao;
	
	@FXML
	TextField textField_CMND;
	
	@FXML
	TextField textField_NgheNghiep;
	
	@FXML
	TextField textField_NoiLamViec;
	
	@FXML
	TextArea textArea_NoiThuongTru_Before;
	
	@FXML
	DatePicker date_Birthday;
	
	@FXML
	DatePicker date_NgayChuyenDen;
	
	@FXML
	ChoiceBox<String> choiceBox_Gender;
	
	@FXML
	TextArea textArea_GhiChu;
	
	public void setSoHoKhau(Information_NhanKhau nhankhau) {
			choiceBox_Gender.getItems().addAll("Nam","Nu");
			textField_QHCH.setText(nhankhau.getQuan_he_chu_ho());
			textField_Name.setText(nhankhau.getName());
			textField_NameOther.setText(nhankhau.getBi_danh());
			textField_QueQuan.setText(nhankhau.getAddress());
			textField_DanToc.setText(nhankhau.getDan_toc());
			textField_TonGiao.setText("None");
			textField_CMND.setText(nhankhau.getCmnd());
			textField_NoiLamViec.setText(nhankhau.getNoi_lam_viec());
			textField_NgheNghiep.setText(nhankhau.getNghe_nghiep());
			textArea_NoiThuongTru_Before.setText(nhankhau.getDia_chi_truoc());
			date_Birthday.setValue(LocalDate.parse(nhankhau.getBirth()));
			date_NgayChuyenDen.setValue(LocalDate.parse(nhankhau.getNgay_dang_ki()));
			choiceBox_Gender.setValue(nhankhau.getGender());
	}
	public void setGhiChu(String s) {
		textArea_GhiChu.setText(s);
	}
	
	public void goBack_BangThongKe(ActionEvent e) throws IOException {
			Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
			if (BangThongKe_Controller.kt_SHK==true) 
				 stage.setScene(BangThongKe_Controller.scene_ThongKe_SHK);
			else
				stage.setScene(ThongKe_Controller.scene_BangThongKe);
			
			stage.setTitle("DANH SÁCH THỐNG KÊ");
			stage.setResizable(false);
	}
}
