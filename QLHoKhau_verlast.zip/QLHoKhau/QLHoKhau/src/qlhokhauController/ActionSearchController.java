
package qlhokhauController;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class ActionSearchController implements Initializable {

    @FXML
        public void NhanKhauSearch(ActionEvent event) throws IOException{
          
            
            Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("SearchNhanKhauChuyen.fxml"));
            Parent sampleParent = loader.load();
            Scene scene = new Scene(sampleParent);
            stage.setTitle("Tìm kiếm theo thay đổi nhân khẩu trong năm");
            stage.setScene(scene);   
            
            
        }
        
    @FXML
        public void HoKhauSearch(ActionEvent event) throws IOException{
           
            
            Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("SearchHoKhauChuyen.fxml"));
            Parent sampleParent = loader.load();
            Scene scene = new Scene(sampleParent);
            stage.setTitle("Tìm kiếm theo thay đổi hộ khẩu trong năm");
            stage.setScene(scene);   
            
        }
    @FXML
    public void goBack(ActionEvent event) throws IOException {
        
        
         Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
         FXMLLoader loader = new FXMLLoader();
         loader.setLocation(getClass().getResource("Search.fxml"));
         Parent sampleParent = loader.load();
         Scene scene = new Scene(sampleParent);
         stage.setTitle("Tìm kiếm");
         stage.setScene(scene);   

    }
        
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
