package qlhokhauController;

import dao.TimKiemNhanKhauChuyenDao;
import dao.TimKiemNhanKhauDao;
import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.NhanKhau;
import model.NhanKhauChuyen;

public class SearchNhanKhauChuyenController implements Initializable {

    @FXML
    ChoiceBox choice;
    @FXML
    TableView<NhanKhauChuyen> table3;
    @FXML
    TableColumn<NhanKhauChuyen, Integer> id;
    @FXML
    TableColumn<NhanKhauChuyen, Date> ngaychuyen;
    @FXML
    TableColumn<NhanKhauChuyen, String> noiden;
    @FXML
    TableColumn<NhanKhauChuyen, String> lido;
    @FXML
    TableColumn<NhanKhauChuyen, String> cmnd;
    @FXML
    private ObservableList<NhanKhauChuyen> nhanKhauChuyenList;

    @FXML
    public void getListNhanKhauChuyen(ActionEvent event) throws IOException {
        int key = choice.getSelectionModel().getSelectedIndex();
        TimKiemNhanKhauChuyenDao nhanKhauChuyenDao = new TimKiemNhanKhauChuyenDao();
        nhanKhauChuyenList = FXCollections.observableArrayList(
                nhanKhauChuyenDao.getListNhanKhauChuyen(key)
        );
        id.setCellValueFactory(new PropertyValueFactory<>("id"));
        ngaychuyen.setCellValueFactory(new PropertyValueFactory<>("ngayChuyen"));
        noiden.setCellValueFactory(new PropertyValueFactory<>("noiDen"));
        lido.setCellValueFactory(new PropertyValueFactory<>("liDo"));
        cmnd.setCellValueFactory(new PropertyValueFactory<>("cmnd"));
        table3.setItems(nhanKhauChuyenList);
    }

    @FXML
    public void goBack(ActionEvent event) throws IOException {
       
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("ActionSearch.fxml"));
        Parent sampleParent = loader.load();
        Scene scene = new Scene(sampleParent);
        stage.setTitle("Tìm kiếm theo hoạt động");
        stage.setScene(scene); 

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        ObservableList<String> choices = FXCollections.observableArrayList(
                "1", "2", "3", "4", "5", "6",
                "7", "8", "9", "10", "11", "12");

        choice.setItems(choices);
        
    }

}
