
package qlhokhauController;

import dao.TimKiemCaHoChuyenDao;
import dao.TimKiemNhanKhauChuyenDao;
import dao.TimKiemNhanKhauDao;
import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.CaHoChuyen;
import model.NhanKhau;
import model.NhanKhauChuyen;


public class SearchHoKhauChuyenController implements Initializable {
    @FXML
    ChoiceBox choice1;
    @FXML
    TableView<CaHoChuyen> table4;
    @FXML
    TableColumn<CaHoChuyen, Integer> id;
    @FXML
    TableColumn<CaHoChuyen, Date> ngaychuyen;
    @FXML
    TableColumn<CaHoChuyen, String> noiden;
    @FXML
    TableColumn<CaHoChuyen, String> lido;
    @FXML
    TableColumn<CaHoChuyen, String> sohk;
    @FXML
    private ObservableList<CaHoChuyen> hoKhauChuyenList;

    @FXML
    public void getListHoKhauChuyen(ActionEvent event) throws IOException {
        int key = choice1.getSelectionModel().getSelectedIndex();
        TimKiemCaHoChuyenDao caHoChuyenDao = new TimKiemCaHoChuyenDao();
        hoKhauChuyenList = FXCollections.observableArrayList(
                caHoChuyenDao.getListHoKhauChuyen(key)
        );
        id.setCellValueFactory(new PropertyValueFactory<>("id"));
        ngaychuyen.setCellValueFactory(new PropertyValueFactory<>("ngayChuyen"));
        noiden.setCellValueFactory(new PropertyValueFactory<>("noiChuyenDen"));
        lido.setCellValueFactory(new PropertyValueFactory<>("liDo"));
        sohk.setCellValueFactory(new PropertyValueFactory<>("soHk"));
        table4.setItems(hoKhauChuyenList);
    }

    @FXML
    public void goBack(ActionEvent event) throws IOException {
        
        
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("ActionSearch.fxml"));
        Parent sampleParent = loader.load();
        Scene scene = new Scene(sampleParent);
        stage.setTitle("Tìm kiếm theo hoạt động");
        stage.setScene(scene); 

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        ObservableList<String> choices = FXCollections.observableArrayList(
                "1", "2", "3", "4", "5", "6",
                "7", "8", "9", "10", "11", "12");

        choice1.setItems(choices);
    }    
    
}
