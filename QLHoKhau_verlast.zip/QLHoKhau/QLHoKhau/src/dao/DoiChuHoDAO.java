/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DoiChuHoDAO {

    MyConnection conn = new MyConnection();
    private Connection connection;

    public boolean doiChu( String cmnd, String quanHe) {
        String sql = "UPDATE nhan_khau set quan_he_chu_ho = ? where cmnd = ?";
        PreparedStatement ps1 = null;
      
            
        try {
            connection = conn.connect();
            ps1 = connection.prepareStatement(sql);
            ps1.setString(1, quanHe);
            ps1.setString(2, cmnd);
            
            return ps1.executeUpdate()>0;
            
            
        } catch (SQLException ex) {
            Logger.getLogger(DoiChuHoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public  boolean check(String shk, String cmnd){
        String sql = "SELECT * FROM nhan_khau WHERE cmnd=?";
        PreparedStatement ps1 = null;
        ResultSet rs =null;
            
        try {
            connection = conn.connect();
            ps1 = connection.prepareStatement(sql);
            ps1.setString(1, cmnd);
            rs = ps1.executeQuery();
            //System.out.println(rs.next());
            if (rs.next() && rs !=null){
                //System.out.println("okok");
                //rs.next();
                String sohk = rs.getString("so_ho_khau_so_hk");
                return (sohk == null ? shk == null : sohk.equals(shk));
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(DoiChuHoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
       return false ;
    }
    
    
    public void doiSoHK(String shk, String chuMoi){
        String sql = "UPDATE so_ho_khau set chu_ho = ? where so_hk = ?";
        PreparedStatement ps1 = null;
      
            
        try {
            connection = conn.connect();
            ps1 = connection.prepareStatement(sql);
            ps1.setString(1, chuMoi);
            ps1.setString(2, shk);
            ps1.executeUpdate();
            
            
        } catch (SQLException ex) {
            Logger.getLogger(DoiChuHoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
}
