/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hohun
 */
public class QuaDoiDAO {
    MyConnection conn = new MyConnection();
    private Connection connection;
    
   

    public boolean quaDoi(String cmnd, String ngayMat, String noiMat, String noiCap, String lyDo) throws ParseException {
        String sql = "INSERT INTO qua_doi (ngay_mat, noi_mat, nguyen_nhan, noi_cap_giay, nhan_khau_cmnd) VALUES (?, ?, ?, ?, ?)";
        PreparedStatement ps1 = null;
        //TamVangDAO a = new TamVangDAO();
            
        try {
            connection = conn.connect();
            ps1 = connection.prepareStatement(sql);
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
            LocalDate localDate = LocalDate.parse(ngayMat,formatter);
            ps1.setObject(1, localDate);
            ps1.setString(2, noiMat);
            ps1.setString(3, lyDo);
            ps1.setString(4, noiCap);
            ps1.setString(5, cmnd);
            System.out.println("oke qua doi");
            return ps1.executeUpdate()>0;
            
            
        } catch (SQLException ex) {
            Logger.getLogger(DoiChuHoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public void danhDau(String cmnd){
        String sql = "UPDATE nhan_khau set status = ? where cmnd = ?";
        PreparedStatement ps1 = null;
            
        try {
            connection = conn.connect();
            ps1 = connection.prepareStatement(sql);
            
            ps1.setInt(1, 0);
            ps1.setString(2,cmnd);
            ps1.executeUpdate();      
            
        } catch (SQLException ex) {
            Logger.getLogger(DoiChuHoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
}
