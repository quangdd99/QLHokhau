
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.SoHoKhau;


public class TimKiemSoHoKhauDao {
    MyConnection conn = new MyConnection();
    private Connection connection;
    public SoHoKhau getSHKById( String id ){
        String sql = "Select * from so_ho_khau "
                + "where so_hk = "
                + id ;
        PreparedStatement ps = null;
        ResultSet rs = null;
       SoHoKhau sohokhau = new SoHoKhau();
      
        try{
              
            connection = conn.connect();
            ps = connection.prepareStatement(sql);
          
            rs = ps.executeQuery();
            if( rs == null){
                System.out.println("Select sohokhau error");
            }else{
                while(rs.next()){
                    sohokhau.setId(rs.getInt("id"));
                    sohokhau.setSoHk(rs.getString("so_hk"));
                    sohokhau.setChuHo(rs.getString("chu_ho"));
                    sohokhau.setSoNha(rs.getString("so_nha"));
                    sohokhau.setDuongPho(rs.getString("duong_pho"));
                    sohokhau.setPhuong(rs.getString("phuong"));
                    sohokhau.setQuan(rs.getString("quan"));
                    sohokhau.setStatus(rs.getInt("status"));
                    return sohokhau;
                }
            }
        }catch(SQLException ex){
            Logger.getLogger(TimKiemNhanKhauDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
}    

