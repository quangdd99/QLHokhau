/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hohun
 */
public class NhatKyDAO {
    MyConnection conn = new MyConnection();
    private Connection connection;
    public void addNhatKy(String nd){
        String sql = "INSERT INTO nhat_ky_thay_doi (thoi_gian, noi_dung) VALUES (?, ?)";
        PreparedStatement ps1 = null;
        try {
            connection = conn.connect();
            ps1 = connection.prepareStatement(sql);
            ps1.setObject(1, LocalDate.now());
            ps1.setString(2,nd );
            ps1.executeUpdate();
            
            
        } catch (SQLException ex) {
            Logger.getLogger(DoiChuHoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
