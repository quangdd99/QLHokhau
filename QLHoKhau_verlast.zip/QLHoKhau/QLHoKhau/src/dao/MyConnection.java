/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import common.Config;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author LTC
 */
public class MyConnection {

    private Connection connection;

    public Connection connect() {
        try {
            Class.forName(Config.DRIVER);
            connection = (Connection) DriverManager.getConnection(Config.URL, Config.USERNAME, Config.PASSWORD);
//            System.out.println("ok");
        } catch (SQLException ex) {
            Logger.getLogger(MyConnection.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(MyConnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        return connection;
    }
    public static void main(String[] args) {
        MyConnection c= new MyConnection();
        c.connect();
    }
}


