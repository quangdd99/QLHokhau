/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import javafx.scene.control.Alert;

/**
 *
 * @author hohun
 */
public class ThongBaoDAO {
    public void showErrorText(String data) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Lỗi");
 
        // Header Text: null
        alert.setHeaderText(null);
        alert.setContentText(data);
        alert.showAndWait();
    }
    public void showSuccessText(String data) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Thành công");
 
        // Header Text: null
        alert.setHeaderText(null);
        alert.setContentText(data);
        alert.showAndWait();
    }
}
