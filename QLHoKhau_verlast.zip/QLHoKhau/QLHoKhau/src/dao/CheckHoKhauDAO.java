/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hohun
 */
public class CheckHoKhauDAO {
    MyConnection conn = new MyConnection();
    private Connection connection;
    public  boolean check(String ten, String shk){
        String sql = "SELECT * FROM so_ho_khau WHERE so_hk=?";
        PreparedStatement ps1 = null;
        ResultSet rs =null;
            
        try {
            connection = conn.connect();
            ps1 = connection.prepareStatement(sql);
            ps1.setString(1, shk);
            rs = ps1.executeQuery();
            if (rs !=null && rs.next()){
                //rs.next();
                String name = rs.getString("chu_ho");
                return (name == null ? ten == null : name.equals(ten));
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(DoiChuHoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
       return false ;
    }
}
