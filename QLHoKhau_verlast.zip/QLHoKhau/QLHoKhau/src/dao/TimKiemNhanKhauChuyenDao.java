package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.NhanKhauChuyen;

public class TimKiemNhanKhauChuyenDao {

    MyConnection conn = new MyConnection();
    private Connection connection;

    public List<NhanKhauChuyen> getListNhanKhauChuyen(int key) {
        String sql = "Select * from nhan_khau_chuyen "
                + " where (month(current_timestamp()) - month(ngay_chuyen)) < "
                + key + 
                " and year(current_timestamp()) - year(ngay_chuyen) = 0 ";
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<NhanKhauChuyen> nhankhauchuyens = new ArrayList<>();
        try {
            connection = conn.connect();
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            if (rs == null) {
                System.out.println("select nhankhauchuyen error");
            } else {
                while (rs.next()) {
                    NhanKhauChuyen nkc = new NhanKhauChuyen();
                    nkc.setId(rs.getInt("id"));
                    nkc.setNgayChuyen(rs.getDate("ngay_chuyen"));
                    nkc.setNoiDen(rs.getString("noi_den"));
                    nkc.setLiDo(rs.getString("li_do"));
                    nkc.setCmnd(rs.getString("nhan_khau_cmnd"));
                    nhankhauchuyens.add(nkc);
                    
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(TimKiemNhanKhauDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return nhankhauchuyens;
    }
//    public static void main(String[] args) {
//        TimKiemNhanKhauChuyenDao nk = new TimKiemNhanKhauChuyenDao();
//        nk.getListNhanKhauChuyen(5);
//        System.out.println("hbhb");
//    }
   
}

