
package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.CaHoChuyen;
import model.NhanKhauChuyen;

public class TimKiemCaHoChuyenDao {
    MyConnection conn = new MyConnection();
    private Connection connection;

    public List<CaHoChuyen> getListHoKhauChuyen(int key) {
        String sql = "Select * from ca_ho_chuyen "
                + " where (month(current_timestamp()) - month(ngay_chuyen)) < "
                + key + 
                " and year(current_timestamp()) - year(ngay_chuyen) = 0 ";
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<CaHoChuyen> cahochuyens = new ArrayList<>();
        try {
            connection = conn.connect();
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            if (rs == null) {
                System.out.println("select cahochuyen error");
            } else {
                while (rs.next()) {
                    CaHoChuyen chc = new CaHoChuyen();
                    chc.setId(rs.getInt("id"));
                    chc.setNgayChuyen(rs.getDate("ngay_chuyen"));
                    chc.setNoiChuyenDen(rs.getString("noi_chuyen_den"));
                    chc.setLiDo(rs.getString("li_do"));
                    chc.setSoHk(rs.getString("so_ho_khau_so_hk"));
                    cahochuyens.add(chc);
                    
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(TimKiemNhanKhauDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return cahochuyens;
    }
}
