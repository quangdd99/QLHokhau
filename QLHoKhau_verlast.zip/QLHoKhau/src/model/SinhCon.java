
package model;

import java.sql.Date;


public class SinhCon {
    private int id;
    private String ten;
    private String biDanh;
    private String gioiTinh;
    private String quanHeChuHo;
    private Date ngaySinh;
    private String noiSinh;
    private String queQuan;
    private String danToc;
    private String ngheNghiep;
    private String cmnd;
    private String noiLamViec;
    private Date ngayCap;
    private String noiCap;
    private Date ngayDangKy;
    private String diaChiTruoc;
    private String soHk;
    private int status;

    public SinhCon() {
    }

    public SinhCon(int id, String ten, String biDanh, String gioiTinh, String quanHeChuHo, Date ngaySinh, String noiSinh, String queQuan, String danToc, String ngheNghiep, String cmnd, String noiLamViec, Date ngayCap, String noiCap, Date ngayDangKy, String diaChiTruoc, String soHk, int status) {
        this.id = id;
        this.ten = ten;
        this.biDanh = biDanh;
        this.gioiTinh = gioiTinh;
        this.quanHeChuHo = quanHeChuHo;
        this.ngaySinh = ngaySinh;
        this.noiSinh = noiSinh;
        this.queQuan = queQuan;
        this.danToc = danToc;
        this.ngheNghiep = ngheNghiep;
        this.cmnd = cmnd;
        this.noiLamViec = noiLamViec;
        this.ngayCap = ngayCap;
        this.noiCap = noiCap;
        this.ngayDangKy = ngayDangKy;
        this.diaChiTruoc = diaChiTruoc;
        this.soHk = soHk;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public String getBiDanh() {
        return biDanh;
    }

    public void setBiDanh(String biDanh) {
        this.biDanh = biDanh;
    }

    public String getGioiTinh() {
        return gioiTinh;
    }

    public void setGioiTinh(String gioiTinh) {
        this.gioiTinh = gioiTinh;
    }

    public String getQuanHeChuHo() {
        return quanHeChuHo;
    }

    public void setQuanHeChuHo(String quanHeChuHo) {
        this.quanHeChuHo = quanHeChuHo;
    }

    public Date getNgaySinh() {
        return ngaySinh;
    }

    public void setNgaySinh(Date ngaySinh) {
        this.ngaySinh = ngaySinh;
    }

    public String getNoiSinh() {
        return noiSinh;
    }

    public void setNoiSinh(String noiSinh) {
        this.noiSinh = noiSinh;
    }

    public String getQueQuan() {
        return queQuan;
    }

    public void setQueQuan(String queQuan) {
        this.queQuan = queQuan;
    }

    public String getDanToc() {
        return danToc;
    }

    public void setDanToc(String danToc) {
        this.danToc = danToc;
    }

    public String getNgheNghiep() {
        return ngheNghiep;
    }

    public void setNgheNghiep(String ngheNghiep) {
        this.ngheNghiep = ngheNghiep;
    }

    public String getCmnd() {
        return cmnd;
    }

    public void setCmnd(String cmnd) {
        this.cmnd = cmnd;
    }

    public String getNoiLamViec() {
        return noiLamViec;
    }

    public void setNoiLamViec(String noiLamViec) {
        this.noiLamViec = noiLamViec;
    }

    public Date getNgayCap() {
        return ngayCap;
    }

    public void setNgayCap(Date ngayCap) {
        this.ngayCap = ngayCap;
    }

    public String getNoiCap() {
        return noiCap;
    }

    public void setNoiCap(String noiCap) {
        this.noiCap = noiCap;
    }

    public Date getNgayDangKy() {
        return ngayDangKy;
    }

    public void setNgayDangKy(Date ngayDangKy) {
        this.ngayDangKy = ngayDangKy;
    }

    public String getDiaChiTruoc() {
        return diaChiTruoc;
    }

    public void setDiaChiTruoc(String diaChiTruoc) {
        this.diaChiTruoc = diaChiTruoc;
    }

    public String getSoHk() {
        return soHk;
    }

    public void setSoHk(String soHk) {
        this.soHk = soHk;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    
    
}
