package model;

import java.sql.Date;

public class NhatKiThayDoi {
    int stt;
    Date thoiGian;
    String noiDung;

    public int getStt() {
        return stt;
    }

    public void setStt(int stt) {
        this.stt = stt;
    }

    public Date getThoiGian() {
        return thoiGian;
    }

    public void setThoiGian(Date thoiGian) {
        this.thoiGian = thoiGian;
    }

    public String getNoiDung() {
        return noiDung;
    }

    public void setNoiDung(String noiDung) {
        this.noiDung = noiDung;
    }

    public NhatKiThayDoi(int stt, Date thoiGian, String noiDung) {
        this.stt = stt;
        this.thoiGian = thoiGian;
        this.noiDung = noiDung;
    }
}
