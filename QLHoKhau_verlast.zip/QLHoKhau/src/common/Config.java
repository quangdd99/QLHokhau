/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package common;

/**
 *
 * @author LTC
 */
public class Config {
    public static String DRIVER = "com.mysql.cj.jdbc.Driver";
    public static String URL = "jdbc:mysql://localhost:3306/ho_khau";
    public static String USERNAME = "root";
    public static String PASSWORD = "Thuyetc@m3t";
}
