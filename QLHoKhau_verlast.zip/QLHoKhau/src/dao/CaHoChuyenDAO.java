/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hohun
 */
public class CaHoChuyenDAO {
    MyConnection conn = new MyConnection();
    private Connection connection;
    
   

    public boolean caHoChuyen( String shk, String tg, String noiDen, String liDo) throws ParseException {
        String sql = "INSERT INTO ca_ho_chuyen (so_ho_khau_so_hk, ngay_chuyen, noi_chuyen_den, li_do) VALUES (?, ?, ?, ?)";
        PreparedStatement ps1 = null;
            
        try {
            connection = conn.connect();
            ps1 = connection.prepareStatement(sql);
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
            ps1.setString(1, shk);
            LocalDate localDate1 = LocalDate.parse(tg,formatter);
//            Date date2 = formatter.parse(tgDen);
            ps1.setObject(2, localDate1);
            ps1.setObject(3, noiDen);
            //ps1.setDate(3, (java.sql.Date) date2);

            ps1.setString(4, liDo);
            
            return ps1.executeUpdate()>0;
            
            
        } catch (SQLException ex) {
            Logger.getLogger(DoiChuHoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    public void danhDau(int values,String shk){
        String sql="";
        switch(values){
            case 1:
                sql = "UPDATE so_ho_khau SET status = ? where so_hk = ?";
                break;
            case 2:
                sql = "UPDATE nhan_khau SET status = ? where so_ho_khau_so_hk = ?";
                break;
        }
        PreparedStatement ps1;
            
        try {
            connection = conn.connect();
            ps1 = connection.prepareStatement(sql);
            ps1.setInt(1, 0);
            ps1.setString(2,shk);
            ps1.executeUpdate();      
            
        } catch (SQLException ex) {
            Logger.getLogger(DoiChuHoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }  
            
        
    }
    

}
