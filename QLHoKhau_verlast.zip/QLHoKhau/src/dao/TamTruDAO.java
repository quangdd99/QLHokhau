/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hohun
 */
public class TamTruDAO {
    MyConnection conn = new MyConnection();
    private Connection connection;
    
   

    public boolean tamTru( String ten, String ns, String cmnd, String ngc, String nc, String dcTruoc, String dcNay, String tu, String den) throws ParseException {
        String sql = "INSERT INTO tam_tru (ten, ngay_sinh, cmnd, cap_ngay,noi_cap, dc_thuong_tru, dc_hien_nay, tg_tu, tg_het) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement ps1 = null;
        //TamVangDAO a = new TamVangDAO();
            
        try {
            connection = conn.connect();
            ps1 = connection.prepareStatement(sql);
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
            ps1.setString(1, ten);
            LocalDate localDate1 = LocalDate.parse(ns,formatter);
            ps1.setObject(2, localDate1);
            ps1.setString(3, cmnd);
            LocalDate localDate2 = LocalDate.parse(ngc,formatter);
            ps1.setObject(4, localDate2);
            ps1.setString(5, nc);
            ps1.setString(6,dcTruoc);
            ps1.setString(7,dcNay);
            LocalDate localDate3 = LocalDate.parse(tu,formatter);
            ps1.setObject(8, localDate3);
            LocalDate localDate4 = LocalDate.parse(den,formatter);
            ps1.setObject(9, localDate4);
            
            return ps1.executeUpdate()>0;
            
            
        } catch (SQLException ex) {
            Logger.getLogger(DoiChuHoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
}
