/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hohun
 */
public class TamVangDAO {
    MyConnection conn = new MyConnection();
    private Connection connection;
    
   

    public boolean tamvang( String noiDen, String tgTu, String tgDen, String liDo, String cmnd) throws ParseException {
        String sql = "INSERT INTO tam_vang (noi_den, tg_tu, tg_het, li_do,nhan_khau_cmnd) VALUES (?, ?, ?, ?, ?)";
        PreparedStatement ps1 = null;
        //TamVangDAO a = new TamVangDAO();
            
        try {
            connection = conn.connect();
            ps1 = connection.prepareStatement(sql);
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
            ps1.setString(1, noiDen);
            LocalDate localDate1 = LocalDate.parse(tgTu,formatter);
            LocalDate localDate2 = LocalDate.parse(tgDen,formatter);
//            Date date2 = formatter.parse(tgDen);
            ps1.setObject(2, localDate1);
            ps1.setObject(3, localDate2);
            //ps1.setDate(3, (java.sql.Date) date2);

            ps1.setString(4, liDo);
            ps1.setString(5, cmnd);
                        return ps1.executeUpdate()>0;
            
            
        } catch (SQLException ex) {
            Logger.getLogger(DoiChuHoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    
    
    

}
