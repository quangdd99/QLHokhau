
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.NhanKhau;


public class TimKiemNhanKhauDao {
    MyConnection conn = new MyConnection();
    private Connection connection;
    public List<NhanKhau> getListNhanKhau(String key){
        String sql = "Select * from nhan_khau "
                   + "where ten like '%"+ key +
                   "%' or cmnd like '%" + key + 
                   "%' or so_ho_khau_so_hk like '%" + key + "%'" ;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<NhanKhau> nhankhaus = new ArrayList<>();
        try{
            connection = conn.connect();
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            if( rs == null){
                System.out.println("select nhankhau error");
            }else{
                while(rs.next()){
                    NhanKhau nhankhau = new NhanKhau();
                    nhankhau.setId(rs.getInt("id"));
                    nhankhau.setTen(rs.getString("ten"));
                    nhankhau.setBiDanh(rs.getString("bi_danh"));
                    nhankhau.setGioiTinh(rs.getString("gioi_tinh"));
                    nhankhau.setQuanHeChuHo(rs.getString("quan_he_chu_ho"));
                    nhankhau.setNgaySinh(rs.getDate("ngay_sinh"));
                    nhankhau.setQueQuan(rs.getString("que_quan"));
                    nhankhau.setNoiSinh(rs.getString("noi_sinh"));
                    nhankhau.setDanToc(rs.getString("dan_toc"));
                    nhankhau.setNgheNghiep(rs.getString("nghe_nghiep"));
                    nhankhau.setNoiLamViec(rs.getString("noi_lam_viec"));
                    nhankhau.setCmnd(rs.getString("cmnd"));
                    nhankhau.setNgayCap(rs.getDate("ngay_cap"));
                    nhankhau.setNoiCap(rs.getString("noi_cap"));
                    nhankhau.setNgayDangKy(rs.getDate("ngay_dang_ki"));
                    nhankhau.setDiaChiTruoc(rs.getString("dia_chi_truoc"));
//                    String idSHK = rs.getString("so_ho_khau_so_hk");
//                    SoHoKhauDao soHoKhauDao = new SoHoKhauDao();
//                    SoHoKhau s = soHoKhauDao.getSHKById(idSHK);
//                    nhankhau.setSoHk(s);
                    
                  
                    nhankhau.setSoHk(rs.getString("so_ho_khau_so_hk"));
                    nhankhau.setStatus(rs.getInt("status"));
                    nhankhaus.add(nhankhau);
                }
            }
        } catch(SQLException ex){
            Logger.getLogger(TimKiemNhanKhauDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return nhankhaus;
    }
}
