/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.TamTru;

/**
 *
 * @author LTC
 */
public class TimKiemTamTruDao {
    MyConnection conn= new MyConnection();
    private Connection connection;
    public List<TamTru> getListTamTru(String ml){
        String sql = "select * from tam_tru where ten like %"
                + ml + "% or cmnd like %"
                +ml+ "%";
            PreparedStatement ps = null;
            ResultSet  rs = null;
            List<TamTru> tamtrus = new ArrayList<>();
        try {
            connection = conn.connect();
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            if( rs == null){
                System.out.println("select tamtru error");
            }else{
                while(rs.next()){
                    TamTru tamtru = new TamTru();
                    tamtru.setId(rs.getInt("id"));
                    tamtru.setCmnd(rs.getString("cmnd"));
                    tamtru.setNgaySinh(rs.getDate("ngay_sinh"));
                    tamtru.setTen(rs.getString("ten"));
                    tamtru.setNgayCap(rs.getDate("cap_ngay"));
                    tamtru.setNoiCap(rs.getString("noi_cap"));
                    tamtru.setDcThuongTru(rs.getString("dc_thuong_tru"));
                    tamtru.setDcHienNay(rs.getString("dc_hien_nay"));
                    tamtru.setTgTu(rs.getDate("tg_tu"));
                    tamtru.setTgHet(rs.getDate("tg_het"));
                    tamtrus.add(tamtru);
                }
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(TimKiemTamTruDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return tamtrus;
    }
    
    
}
