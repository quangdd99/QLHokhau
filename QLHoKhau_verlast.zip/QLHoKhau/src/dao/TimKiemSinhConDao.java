
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.SinhCon;


public class TimKiemSinhConDao {
    MyConnection conn = new MyConnection();
    private Connection connection;
    public List<SinhCon> getListSinhCon(String key){
        String sql = "Select * from sinh_con "
                   + "where ten like '%"+ key +
                   "%' or cmnd like '%" + key + 
                   "%' or so_ho_khau_so_hk like '%" + key + "%'" ;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<SinhCon> sinhcons = new ArrayList<>();
        try{
            connection = conn.connect();
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            if( rs == null){
                System.out.println("select sinhcon error");
            }else{
                while(rs.next()){
                    SinhCon sc = new SinhCon();
                    sc.setId(rs.getInt("id"));
                    sc.setTen(rs.getString("ten"));
                    sc.setBiDanh(rs.getString("bi_danh"));
                    sc.setGioiTinh(rs.getString("gioi_tinh"));
                    sc.setQuanHeChuHo(rs.getString("quan_he_chu_ho"));
                    sc.setNgaySinh(rs.getDate("ngay_sinh"));
                    sc.setQueQuan(rs.getString("que_quan"));
                    sc.setNoiSinh(rs.getString("noi_sinh"));
                    sc.setDanToc(rs.getString("dan_toc"));
                    sc.setNgheNghiep(rs.getString("nghe_nghiep"));
                    sc.setNoiLamViec(rs.getString("noi_lam_viec"));
                    sc.setCmnd(rs.getString("cmnd"));
                    sc.setNgayCap(rs.getDate("ngay_cap"));
                    sc.setNoiCap(rs.getString("noi_cap"));
                    sc.setNgayDangKy(rs.getDate("ngay_dang_ki"));
                    sc.setDiaChiTruoc(rs.getString("dia_chi_truoc"));
                    sc.setSoHk(rs.getString("so_ho_khau_so_hk"));
                    sc.setStatus(rs.getInt("status"));
                    sinhcons.add(sc);
                }
            }
        } catch(SQLException ex){
            Logger.getLogger(TimKiemSinhConDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return sinhcons;
    }
}
