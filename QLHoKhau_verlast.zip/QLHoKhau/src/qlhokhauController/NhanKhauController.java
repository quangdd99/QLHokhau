package qlhokhauController;

import dao.NhatKyDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.MainQuanLy;
import model.NhanKhau;

import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class NhanKhauController implements Initializable {
    @FXML
    private TableView<NhanKhau> table;

    @FXML
    private TableColumn<NhanKhau, Integer> id;
    @FXML
    private TableColumn<NhanKhau, String> ten;
    @FXML
    private TableColumn<NhanKhau, String> biDanh;
    @FXML
    private TableColumn<NhanKhau, String> gioiTinh;
    @FXML
    private TableColumn<NhanKhau, String> quanHeChuHo;
    @FXML
    private TableColumn<NhanKhau, Date> ngaySinh;
    @FXML
    private TableColumn<NhanKhau, String> noiSinh;
    @FXML
    private TableColumn<NhanKhau, String> queQuan;
    @FXML
    private TableColumn<NhanKhau, String> danToc;
    @FXML
    private TableColumn<NhanKhau, String> ngheNghiep;
    @FXML
    private TableColumn<NhanKhau, String> noiLamViec;
    @FXML
    private TableColumn<NhanKhau, String> cmnd;
    @FXML
    private TableColumn<NhanKhau, Date> ngayCap;
    @FXML
    private TableColumn<NhanKhau, String> noiCap;
    @FXML
    private TableColumn<NhanKhau, Date> ngayDangKi;
    @FXML
    private TableColumn<NhanKhau, String> diaChiTruoc;
    @FXML
    private TableColumn<NhanKhau, String> soHK;
    @FXML
    private TableColumn<NhanKhau, Integer> status;



    private ObservableList<NhanKhau> nhanKhauList;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        nhanKhauList = FXCollections.observableArrayList();

          try {
            ShowNhanKhau();
        } catch (SQLException e) {
        }

        id.setCellValueFactory(new PropertyValueFactory<NhanKhau, Integer>("id"));
        ten.setCellValueFactory(new PropertyValueFactory<NhanKhau, String>("ten"));
        biDanh.setCellValueFactory(new PropertyValueFactory<NhanKhau, String>("biDanh"));
        gioiTinh.setCellValueFactory(new PropertyValueFactory<NhanKhau, String>("gioiTinh"));
        quanHeChuHo.setCellValueFactory(new PropertyValueFactory<NhanKhau, String>("quanHeChuHo"));
        ngaySinh.setCellValueFactory(new PropertyValueFactory<NhanKhau, Date>("ngaySinh"));
        noiSinh.setCellValueFactory(new PropertyValueFactory<NhanKhau, String>("noiSinh"));
        queQuan.setCellValueFactory(new PropertyValueFactory<NhanKhau, String>("queQuan"));
        danToc.setCellValueFactory(new PropertyValueFactory<NhanKhau, String>("danToc"));
        ngheNghiep.setCellValueFactory(new PropertyValueFactory<NhanKhau, String>("ngheNghiep"));
        noiLamViec.setCellValueFactory(new PropertyValueFactory<NhanKhau, String>("noiLamViec"));
        cmnd.setCellValueFactory(new PropertyValueFactory<NhanKhau, String>("cmnd"));
        ngayCap.setCellValueFactory(new PropertyValueFactory<NhanKhau, Date>("ngayCap"));
        noiCap.setCellValueFactory(new PropertyValueFactory<NhanKhau, String>("noiCap"));
        ngayDangKi.setCellValueFactory(new PropertyValueFactory<NhanKhau, Date>("ngayDangKy"));
        diaChiTruoc.setCellValueFactory(new PropertyValueFactory<NhanKhau, String>("diaChiTruoc"));
        soHK.setCellValueFactory(new PropertyValueFactory<NhanKhau, String>("soHk"));
        status.setCellValueFactory(new PropertyValueFactory<NhanKhau, Integer>("status"));

        table.setItems(nhanKhauList);
    }

    @FXML
    private void addNhanKhau() throws IOException, SQLException {

        Parent secondaryLayout = FXMLLoader.load(getClass().getResource("addNhanKhau.fxml"));
        Scene secondScene = new Scene(secondaryLayout);
        Stage newWindow = new Stage();
        newWindow.setTitle("Thêm nhân khẩu");
        newWindow.setScene(secondScene);
        newWindow.setResizable(false);

        // Chỉ định modality (thể thức) cho cửa sổ mới.
        newWindow.initModality(Modality.NONE);

        // Chỉ định chủ sở hữu (cửa sổ cha) của cửa sổ mới.
        newWindow.initOwner(QLHoKhau.primaryStage);

        // Sét đặt vị trí cho cửa sổ thứ 2.
        // Có vị trí tương đối đối với cửa sổ chính.
        newWindow.setX(QLHoKhau.primaryStage.getX() + 10);
        newWindow.setY(QLHoKhau.primaryStage.getY() + 10);

        newWindow.show();
    }

    @FXML
    private void xoaNhanKhau() throws SQLException {
        String deletedCmnd = table.getSelectionModel().getSelectedItem().getCmnd();
        ResultSet resultSet=MainQuanLy.statement.executeQuery("select * from nhan_khau where nhan_khau.cmnd="+deletedCmnd+"");
        while(resultSet.next()){
            int id = resultSet.getInt("id");
            String ten = resultSet.getString("ten");
            String biDanh = resultSet.getString("bi_danh");
            String gioiTinh = resultSet.getString("gioi_tinh");
            String quanHeChuHo = resultSet.getString("quan_he_chu_ho");
            Date ngaySinh = resultSet.getDate("ngay_sinh");
            String noiSinh = resultSet.getString("noi_sinh");
            String queQuan = resultSet.getString("que_quan");
            String danToc = resultSet.getString("dan_toc");
            String ngheNghiep = resultSet.getString("nghe_nghiep");
            String noiLamViec = resultSet.getString("noi_lam_viec");
            String cmnd = resultSet.getString("cmnd");
            Date ngayCap = resultSet.getDate("ngay_cap");
            String noiCap = resultSet.getString("noi_cap");
            Date ngayDangKi = resultSet.getDate("ngay_dang_ki");
            String diaChiTruoc = resultSet.getString("dia_chi_truoc");
            String soHK = resultSet.getString("so_ho_khau_so_hk");
            int status = resultSet.getInt("status");
            
        String noiDung = "Xóa nhân khẩu số: "+id +" tên "+ten+" cmnd: "+cmnd+" qua thao tác trực tiếp";
                NhatKyDAO k = new NhatKyDAO();
                k.addNhatKy(noiDung);
        }
        	resultSet.close();
        	System.out.println(deletedCmnd);
                MainQuanLy.statement.executeUpdate("DELETE FROM ho_khau.nhan_khau WHERE  nhan_khau.cmnd =  " + deletedCmnd + ";");
                 ShowNhanKhau();

    }


    @FXML
    private void ShowNhanKhau() throws SQLException {
    	ResultSet resultSet=MainQuanLy.statement.executeQuery("select * from nhan_khau");
        nhanKhauList.clear();
        while (resultSet.next()){
            int id = resultSet.getInt("id");
            String ten = resultSet.getString("ten");
            String biDanh = resultSet.getString("bi_danh");
            String gioiTinh = resultSet.getString("gioi_tinh");
            String quanHeChuHo = resultSet.getString("quan_he_chu_ho");
            Date ngaySinh = resultSet.getDate("ngay_sinh");
            String noiSinh = resultSet.getString("noi_sinh");
            String queQuan = resultSet.getString("que_quan");
            String danToc = resultSet.getString("dan_toc");
            String ngheNghiep = resultSet.getString("nghe_nghiep");
            String noiLamViec = resultSet.getString("noi_lam_viec");
            String cmnd = resultSet.getString("cmnd");
            Date ngayCap = resultSet.getDate("ngay_cap");
            String noiCap = resultSet.getString("noi_cap");
            Date ngayDangKi = resultSet.getDate("ngay_dang_ki");
            String diaChiTruoc = resultSet.getString("dia_chi_truoc");
            String soHK = resultSet.getString("so_ho_khau_so_hk");
            int status = resultSet.getInt("status");

            nhanKhauList.add(new NhanKhau(id, ten, biDanh, gioiTinh, quanHeChuHo, ngaySinh, noiSinh, queQuan, danToc, ngheNghiep, cmnd, noiLamViec, ngayCap, noiCap, ngayDangKi, diaChiTruoc, soHK, status));
            
        }
    }

    @FXML
    private void backToHome() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("menu.fxml"));
        QLHoKhau.primaryStage.setTitle("Quản lí hộ khẩu");
        QLHoKhau.primaryStage.setScene(new Scene(root));
        QLHoKhau.primaryStage.show();
    }
}
