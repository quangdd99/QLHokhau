/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package qlhokhauController;

import dao.CheckNhanKhauDAO;
import dao.NhatKyDAO;
import dao.TamVangDAO;
import dao.ThongBaoDAO;
import java.io.IOException;
import java.net.URL;
import java.text.ParseException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author hohun
 */
public class TamVangController implements Initializable {

    /**
     * Initializes the controller class.
     */
    
    @FXML
    TextField hoTen;
    
    @FXML
    TextField cmnd;
    
    @FXML
    TextField tGianTu;
    
    @FXML
    TextField tGianDen;
    
    @FXML
    TextField noiDen;
    
    @FXML
    TextArea lyDo;
    
    @FXML
    private void actionOK(ActionEvent event) throws ParseException  {
        String ht = hoTen.getText();
        String cm = cmnd.getText();
        String tu = tGianTu.getText(); 
        String den = tGianDen.getText();
        String nd = noiDen.getText();
        String ld = lyDo.getText();
        
        ThongBaoDAO e = new ThongBaoDAO();
        if ("".equals(ht) || "".equals(cm) || "".equals(tu) || "".equals(den) || "".equals(nd) || "".equals(ld)){
            e.showErrorText("Thông tin còn thiếu!");
        }
        else{
            CheckNhanKhauDAO c = new CheckNhanKhauDAO();
            if (!c.check(ht, cm)){
                e.showErrorText("Thông tin nhân khẩu không đúng!");
            }
            else{
                TamVangDAO p = new TamVangDAO();
                p.tamvang(nd,tu,den, ld, cm);
        
                String noiDung = "Đăng ký tạm vắng: "+ht+" cmnd:"+cm+" Từ "+tu+" đến "+den+" .Nơi đến: "+nd+" \n Lý do:"+ld;
                NhatKyDAO k = new NhatKyDAO();
                k.addNhatKy(noiDung);
                e.showSuccessText("Đăng ký tạm vắng thành công");
                hoTen.clear();
                cmnd.clear();
                tGianTu.clear();
                tGianDen.clear();
                noiDen.clear();
                lyDo.clear();
            }
        }
    }
    @FXML
    private void actionTroLai(ActionEvent event) throws IOException {
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("Sua.fxml"));
        Parent sampleParent = loader.load();
        Scene scene = new Scene(sampleParent);
        stage.setScene(scene);
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
