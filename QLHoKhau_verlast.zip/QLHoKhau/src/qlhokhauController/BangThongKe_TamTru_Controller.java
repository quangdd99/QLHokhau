package qlhokhauController;

import java.net.URL;
import java.sql.Date;
import java.util.ResourceBundle;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.MainQuanLy;
import model.TamTru;
/**
 * 
 * @Author: Lương Ngọc Thuyết
 * MSSV:20183994
 */
public class BangThongKe_TamTru_Controller implements Initializable{
	@FXML
	Button backButton_BangThongKe_TamTru;
	@FXML
	Label label_Number;
	@FXML
	TableView<TamTru> tableView_TamTru;
	@FXML
	TableColumn<TamTru,String> tableColumn_Name_TamTru;
	@FXML
	TableColumn<TamTru,String> tableColumn_Birth_TamTru;
	@FXML
	TableColumn<TamTru,String> tableColumn_CMND_TamTru;
	@FXML
	TableColumn<TamTru,String> tableColumn_DCTT_TamTru;
	@FXML
	TableColumn<TamTru,String> tableColumn_NOHN_TamTru;
	@FXML
	TableColumn<TamTru,Date> tableColumn_From_TamTru;
	@FXML
	TableColumn<TamTru,Date> tableColumn_To_TamTru;
	
	public void setListBangThongKe_TamTru(ObservableList<TamTru> list) {
		tableView_TamTru.setItems(list);
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		tableColumn_Name_TamTru.setCellValueFactory(new PropertyValueFactory<>("ten"));
		tableColumn_Birth_TamTru.setCellValueFactory(new PropertyValueFactory<>("ngaySinh"));
		tableColumn_CMND_TamTru.setCellValueFactory(new PropertyValueFactory<>("cmnd"));
		tableColumn_DCTT_TamTru.setCellValueFactory(new PropertyValueFactory<>("dcThuongTru"));
		tableColumn_NOHN_TamTru.setCellValueFactory(new PropertyValueFactory<>("dcHienNay"));
		tableColumn_From_TamTru.setCellValueFactory(new PropertyValueFactory<>("tgTu"));
		tableColumn_To_TamTru.setCellValueFactory(new PropertyValueFactory<>("tgHet"));
	}
	
	public void action_BackButton_BangThongKe_TamTru(ActionEvent e){
		Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
		stage.setScene(MainQuanLy.scene_ThongKe);
		stage.setTitle("THỐNG KÊ"); 
		stage.setResizable(false);
	}
}
