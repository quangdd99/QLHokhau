/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package qlhokhauController;

import dao.CheckNhanKhauDAO;
import dao.NhatKyDAO;
import dao.TamTruDAO;
import dao.TamVangDAO;
import dao.ThongBaoDAO;
import java.io.IOException;
import java.net.URL;
import java.text.ParseException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author hohun
 */
public class TamTruController implements Initializable {

    /**
     * Initializes the controller class.
     */
    
    @FXML
    TextField hoTen;
    @FXML
    TextField cmnd;
    @FXML
    TextField ngaySinh;
    @FXML
    TextField ngayCap;
    @FXML
    TextField noiCap;
    @FXML
    TextField dcTruoc;
    @FXML
    TextField dcNay;
    @FXML
    TextField tgTu;
    @FXML
    TextField tgDen;
    @FXML
    private void actionDangKy(ActionEvent event) throws ParseException{
        String ht = hoTen.getText();
        String cm = cmnd.getText();
        String tu = tgTu.getText(); 
        String den = tgDen.getText();
        String ns = ngaySinh.getText();
        String ngc = ngayCap.getText();
        String nc = noiCap.getText();
        String dct = dcTruoc.getText();
        String dcn = dcNay.getText();
        
        ThongBaoDAO e = new ThongBaoDAO();
        if ("".equals(ht) || "".equals(cm) || "".equals(tu) || "".equals(den) || "".equals(ns) || "".equals(ngc) || "".equals(nc) || "".equals(dct) || "".equals(dcn)){
            e.showErrorText("Thông tin còn thiếu!");
        }
        
        else{
                TamTruDAO p = new TamTruDAO();
                p.tamTru(ht, ns, cm, ngc, nc, dct, dcn, tu, den);
        
                String noiDung = "Đăng ký tạm trú: "+ht+" cmnd:"+cm+" Từ "+tu+" đến "+den+" .địa chỉ trước đó: "+dct+"  nơi ở hiện tại :"+dcn;
                NhatKyDAO k = new NhatKyDAO();
                k.addNhatKy(noiDung);
                e.showSuccessText("Đăng ký tạm vắng thành công");
                hoTen.clear();
                cmnd.clear();
                tgTu.clear();
                tgDen.clear();
                ngaySinh.clear();
                ngayCap.clear();
                noiCap.clear();
                dcTruoc.clear();
                dcNay.clear();
            
        }
    }
    
    @FXML
    private void actionTroVe(ActionEvent event) throws IOException {
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("Sua.fxml"));
        Parent sampleParent = loader.load();
        Scene scene = new Scene(sampleParent);
        stage.setScene(scene);
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
