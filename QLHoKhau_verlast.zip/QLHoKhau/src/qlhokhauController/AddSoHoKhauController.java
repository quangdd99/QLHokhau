package qlhokhauController;

import dao.NhatKyDAO;
import java.awt.Component;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import model.MainQuanLy;
import model.SoHoKhau;

import javax.swing.JOptionPane;

public class AddSoHoKhauController {
    @FXML
    private TextField id;
    @FXML
    private TextField soHK;
    @FXML
    private TextField chuHo;
    @FXML
    private TextField soNha;
    @FXML
    private TextField duongPho;
    @FXML
    private TextField phuong;
    @FXML
    private TextField quan;
    @FXML
    private TextField status;

    @FXML
    private void Add() {
        int i =0;
        try{
        int _id = Integer.valueOf(id.getText());
        String _soHK = soHK.getText();
        String _chuHo = chuHo.getText();
        String _soNha = soNha.getText();
        String _duongPho = duongPho.getText();
        String _phuong = phuong.getText();
        String _quan = quan.getText();
        int _status = Integer.valueOf(status.getText());

        SoHoKhau shk = new SoHoKhau(_id, _soHK, _chuHo, _soNha, _duongPho, _phuong, _quan, _status);
        String sql = "INSERT INTO `so_ho_khau` VALUES ("+
                id.getText()+ ",'"+
                soHK.getText()+ "','"+
                chuHo.getText()+"','"+
                soNha.getText() + "','"+
                duongPho.getText() + "','"+
                phuong.getText() + "','"+
                quan.getText() + "',"+
                status.getText() +");";
        System.out.println(sql);
        String noiDung = "Thêm hộ khẩu số: "+soHK.getText() +" chủ hộ: "+chuHo.getText()+" ID số: "+id.getText();
                NhatKyDAO k = new NhatKyDAO();
                k.addNhatKy(noiDung);
       MainQuanLy.statement.executeUpdate(sql);}
        catch(Exception e){
            Component frame = null;i=1;
            JOptionPane.showMessageDialog(frame ,"Failed! Please Add again");
        }
        if (i==0){          Component frame = null;
                            JOptionPane.showMessageDialog(frame ,"Completed ! Close form and Refresh to continue!");}
        }
    

    

}
