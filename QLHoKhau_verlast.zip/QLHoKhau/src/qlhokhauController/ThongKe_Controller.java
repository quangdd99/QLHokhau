package qlhokhauController;

import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Optional;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ChoiceDialog;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import model.TamTru;
import model.MainQuanLy;
import model.NhanKhau;
/**
 * 
 * @Author: Lương Ngọc Thuyết
 * MSSV:20183994
 */
public class ThongKe_Controller{
	@FXML
	Button thongKe_HoKhau;
	@FXML
	Button thongKe_Gender;
	@FXML
	Button thongKe_Age;
	@FXML
	Button thongKe_KhoangThoiGian;
	@FXML
	Button thongKe_TamTru;
	@FXML
	Button thongKe_TamVang;
	@FXML
	Button button_Back;
	
	public int year_Now= Calendar.getInstance().get(Calendar.YEAR);
	public Calendar date=Calendar.getInstance();
// List of BangThongKe
	public static ObservableList<NhanKhau> list=FXCollections.observableArrayList();
	
	public static Scene scene_BangThongKe;
	
// Create BangThongKe
	public void setBangThongKe(ActionEvent e){
		Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
		FXMLLoader loader_BangThongKe=new FXMLLoader();
		loader_BangThongKe.setLocation(getClass().getResource("BangThongKe.fxml"));
		Pane root=null;
		try {
			root = loader_BangThongKe.load();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Scene scene=new Scene(root);
		scene_BangThongKe=scene;
		BangThongKe_Controller bangThongKe_Controller=loader_BangThongKe.getController();
		bangThongKe_Controller.setListBangThongKe(list);
		bangThongKe_Controller.label_Number.setText(Integer.toString(list.size()));
		stage.setScene(scene);
		stage.setTitle("DANH SÁCH THỐNG KÊ");
		stage.setResizable(false);
	}
	
// Add Information_NhanKhau to BangThongKe
	public void addToList() {
		try {
			list.add(new NhanKhau(
					MainQuanLy.resultSet.getInt("id"),MainQuanLy.resultSet.getString("ten"), MainQuanLy.resultSet.getString("bi_danh"), 
					MainQuanLy.resultSet.getString("gioi_tinh"), MainQuanLy.resultSet.getString("quan_he_chu_ho"),
					MainQuanLy.resultSet.getDate("ngay_sinh"), MainQuanLy.resultSet.getString("noi_sinh"), MainQuanLy.resultSet.getString("que_quan"),
					MainQuanLy.resultSet.getString("dan_toc"), MainQuanLy.resultSet.getString("nghe_nghiep"), MainQuanLy.resultSet.getString("cmnd"),
					MainQuanLy.resultSet.getString("noi_lam_viec"),MainQuanLy.resultSet.getDate("ngay_cap"), MainQuanLy.resultSet.getString("noi_cap"), 
					MainQuanLy.resultSet.getDate("ngay_dang_ki"),MainQuanLy.resultSet.getString("dia_chi_truoc"), MainQuanLy.resultSet.getString("so_ho_khau_so_hk"), MainQuanLy.resultSet.getInt("status")));
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

// Action Button ThongKe_Gender
	public void action_ThongKe_Gender()  {
		thongKe_Gender.setOnAction(e->{
			
			// Create ChoiceDialog: Choice :Nam/Nu
				ChoiceDialog<String> choiceDialog_Gender=new ChoiceDialog<String>("Nam","Nu");
				choiceDialog_Gender.setTitle("Giới Tính");
				choiceDialog_Gender.setHeaderText("Chon Giới Tính");
				choiceDialog_Gender.setContentText("Giới Tính: ");
				
				Optional<String> result_Gender=choiceDialog_Gender.showAndWait();
				result_Gender.ifPresent(gender->{
					try {
					// Add selected Information_NhanKhau to List of BangThongKe
						list.clear();
						MainQuanLy.setResultSet_NhanKhau();
						while (MainQuanLy.resultSet.next()) {
							if (gender.equals(MainQuanLy.resultSet.getString("gioi_tinh")) && !MainQuanLy.resultSet.getString("status").equals("0")) addToList();
						}
						
					// Create BangThongKE
						setBangThongKe(e);
					
						MainQuanLy.resultSet.close();//close ResultSet
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
				});
		});
	}
	
// Action Button ThongKe_DoTuoi
	public void action_ThongKe_DoTuoi() {
		thongKe_Age.setOnAction(e->{
			
		  // Create ChoiceDialog : Choice :Age
			ChoiceDialog<String> choiceDialog_Age=new ChoiceDialog<String>("Mẫu Giáo","Cấp 1","Cấp 2","Cấp 3","Độ tuổi lao động","Độ tuổi nghỉ hưu");
			choiceDialog_Age.setTitle("Độ tuổi");
			choiceDialog_Age.setHeaderText("Chọn độ tuổi");
			choiceDialog_Age.setContentText("Độ tuổi ");
			
			Optional<String> result_Age=choiceDialog_Age.showAndWait();
			result_Age.ifPresent(age->{
				try {
				// Create coditions in oder to add to List of BangThongKe
					int year1=0;
					int dk1=0,dk2=0;
					if (age.equals("Mẫu Giáo")) {dk2=6;dk1=0;}
					if (age.equals("Cấp 1")) {dk2=11;dk1=6;}
					if (age.equals("Cấp 2")) {dk2=15;dk1=11;}
					if (age.equals("Cấp 3")) {dk2=18;dk1=15;}
					if (age.equals("Độ tuổi lao động")) {dk2=60;dk1=18;}
					if (age.equals("Độ tuổi nghỉ hưu")) {dk2=200; dk1=60;}
					
				// Add selected Information_NhanKhau to List of BangThongKe
					list.clear();
					MainQuanLy.setResultSet_NhanKhau();
					DateFormat format= new SimpleDateFormat("yyyy-MM-dd");
					while (MainQuanLy.resultSet.next()) {
						try {
							date.setTime((format.parse(MainQuanLy.resultSet.getString("ngay_sinh"))));
						} catch (ParseException e1) {
							e1.printStackTrace();
						}
						year1=date.get(Calendar.YEAR);
						if (year_Now-year1>dk1 && year_Now-year1<dk2 && !MainQuanLy.resultSet.getString("status").equals("0")) addToList();
					}
				// Create BangThongKe
					setBangThongKe(e);
					
					MainQuanLy.resultSet.close();//close ResultSet
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			});
		});
	}
	
// Action Button ThongKe_KhoangThoiGian		
	boolean kt_KhoangThoiGian=false;//Text is true format or fasle format?
	public void action_ThongKe_KhoangThoiGian() {
		thongKe_KhoangThoiGian.setOnAction(e->{
		  // Create TextInputDialog : Text :Time
			TextInputDialog textInputDialog_ThongKe_KhoangThoiGian= new TextInputDialog();
			textInputDialog_ThongKe_KhoangThoiGian.setTitle("Thời Gian");
			textInputDialog_ThongKe_KhoangThoiGian.setHeaderText("Chọn khoảng thời gian:");
			textInputDialog_ThongKe_KhoangThoiGian.setContentText("Khoảng Thời Gian:");
			Tooltip toolTip=new Tooltip("yyyy-yyyy");//Hint format text
			TextField textField=textInputDialog_ThongKe_KhoangThoiGian.getEditor();
			textField.setTooltip(toolTip);
			textField.setPromptText("yyyy-yyyy");
			
			Node okButton= textInputDialog_ThongKe_KhoangThoiGian.getDialogPane().lookupButton(ButtonType.OK);
			okButton.setDisable(true);
			textField.textProperty().addListener((observable,oldValue,newValue)->{
				okButton.setDisable(newValue.trim().isEmpty());
			});
			
			GridPane gridPane=(GridPane)(textInputDialog_ThongKe_KhoangThoiGian.getDialogPane().getContent());
			
			kt_KhoangThoiGian=false;
		//Reenter when enter text incorrectly : kt=false
			while (kt_KhoangThoiGian==false) {
				Optional<String> result=textInputDialog_ThongKe_KhoangThoiGian.showAndWait();
				result.ifPresent(value->{
				  // Create conditons in order to add to List of BangThongKe
					int year[]=new int[2];
					value=value.trim();
					if (value.matches("[>][0-9]{1,4}") || value.matches("[<][0-9]{1,4}") || value.matches("[0-9]{1,4}[-][0-9]{1,4}") || value.matches("[0-9]{1,4}")) 
						{
							if (value.matches("[>][0-9]{1,4}")){
								year[0]=Integer.parseInt(value.substring(1));
								if (year[0]>=1000) year[1]=Integer.MAX_VALUE;
								else year[1]=999;
							} else
							if (value.matches("[<][0-9]{1,4}")) {
								year[1]=Integer.parseInt(value.substring(1));
								if (year[1]<1000) year[0]=0;
								else year[0]=1000;
							} else
							if (value.matches("[0-9]{1,4}[-][0-9]{1,4}"))
							{
								String string[]=value.split("\\-",2);
								year[0]=Integer.parseInt(string[0]);
								year[1]=Integer.parseInt(string[1]);
							} else
							if (value.matches("[0-9]{1,4}")) {
								year[0]=Integer.parseInt(value);
								year[1]=Integer.parseInt(value);
							}
							
							DateFormat format= new SimpleDateFormat("yyyy-MM-dd");
						// Add seclected Information to List of BangThongKe
							list.clear();
							MainQuanLy.setResultSet_NhanKhau();
							try {
								while (MainQuanLy.resultSet.next()) {
									try {
										date.setTime((format.parse(MainQuanLy.resultSet.getString("ngay_dang_ki"))));
									} catch (ParseException e1) {
										e1.printStackTrace();
									}
									int year1=date.get(Calendar.YEAR);
									
									if ((((year[0]>=1000 &&  year[1]>=1000) && (year1>=year[0]) && (year1<=year[1]))
										|| (year[0]<1000 && year[1]<1000 && year_Now-year1>=year[0] && year_Now-year1<=year[1]))
											&& !MainQuanLy.resultSet.getString("status").equals("0"))
										addToList();
								}
						// Create BangThongKe
							setBangThongKe(e);
								
								MainQuanLy.resultSet.close();//close ResultSet
							} catch (SQLException e1) {
								e1.printStackTrace();
							}
						kt_KhoangThoiGian=true;//Format is true;
						}
					else{
					// Warning - format is false
						Label warningLabel=new Label("Please try again with format:\nyyyy-yyy, >yyyy, <yyyy\nnn-nn, >nn, <nn\nyyyy,nn");
						warningLabel.setTextFill(Color.RED);
						gridPane.add(warningLabel,1,1);
						}
				});
				if (result.isPresent()==false) break;// When press CANCEL-> exit the loop;
			}
		});
	}

// Action Button ThongKe_TamVang
	public void action_ThongKe_TamVang() {
		thongKe_TamVang.setOnAction(e->{
			try {
				// Add selected Information_NhanKhau to List of BangThongKe
					list.clear();
					MainQuanLy.setResultSet_TamVang();
					while (MainQuanLy.resultSet.next()) addToList();
					
				// Create BangThongKE
					setBangThongKe(e);
				
					MainQuanLy.resultSet.close();//close ResultSet
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
		});
	}

// Action Button ThongKe_TamTru
	public void action_ThongKe_TamTru() {
		thongKe_TamTru.setOnAction(e->{
			try {
				ObservableList<TamTru> list_TamTru=FXCollections.observableArrayList();
				list_TamTru.clear();
				MainQuanLy.setResultSet_TamTru();
				while (MainQuanLy.resultSet.next()) {
					list_TamTru.add(new TamTru(MainQuanLy.resultSet.getString("ten"), MainQuanLy.resultSet.getDate("ngay_sinh"),MainQuanLy.resultSet.getString("cmnd"),
							MainQuanLy.resultSet.getString("dc_thuong_tru"),MainQuanLy.resultSet.getString("dc_hien_nay"), MainQuanLy.resultSet.getDate("tg_tu"), MainQuanLy.resultSet.getDate("tg_het")));
				}
				
				Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
				FXMLLoader loader_BangThongKe_TamTru=new FXMLLoader();
				loader_BangThongKe_TamTru.setLocation(getClass().getResource("BangThongKe_TamTru.fxml"));
				Pane root=null;
				root = loader_BangThongKe_TamTru.load();
				Scene scene=new Scene(root);
				BangThongKe_TamTru_Controller bangThongKe_TamTru_Controller=loader_BangThongKe_TamTru.getController();
				bangThongKe_TamTru_Controller.setListBangThongKe_TamTru(list_TamTru);
				bangThongKe_TamTru_Controller.  label_Number.setText(Integer.toString(list_TamTru.size()));
				stage.setScene(scene);
				stage.setTitle("DANH SÁCH THỐNG KÊ");
				stage.setResizable(false);
				
				MainQuanLy.resultSet.close();//close ResultSet_TamTru
			} catch (SQLException | IOException e1) {
				e1.printStackTrace();
			}
		});
	}
	
// Action Button ThongKe_HoKhau
	boolean kt_SoHoKhau=false;
	public void action_ThongKe_HoKhau() {
		thongKe_HoKhau.setOnAction(e->{
			  // Create TextInputDialog : Text :Time
				TextInputDialog textInputDialog_ThongKe_HoKhau= new TextInputDialog();
				textInputDialog_ThongKe_HoKhau.setTitle("Số Hộ Khẩu");
				textInputDialog_ThongKe_HoKhau.setHeaderText("Chọn Số Hộ Khẩu:");
				textInputDialog_ThongKe_HoKhau.setContentText("Số Hộ Khẩu:");
				Tooltip toolTip=new Tooltip("Số hộ khẩu");//Hint format text
				TextField textField=textInputDialog_ThongKe_HoKhau.getEditor();
				textField.setTooltip(toolTip);
				textField.setPromptText("Số hộ khẩu");
				
				Node okButton= textInputDialog_ThongKe_HoKhau.getDialogPane().lookupButton(ButtonType.OK);
				okButton.setDisable(true);
				textField.textProperty().addListener((observable,oldValue,newValue)->{
					okButton.setDisable(newValue.trim().isEmpty());
				});
				
				GridPane gridPane=(GridPane)(textInputDialog_ThongKe_HoKhau.getDialogPane().getContent());
				
				kt_SoHoKhau=false;
			//Reenter when enter incorrectly : kt=false
				while (kt_SoHoKhau==false) {
					Optional<String> result=textInputDialog_ThongKe_HoKhau.showAndWait();
					result.ifPresent(value->{
						value=value.trim();
						if(value.matches("[0-9]+")){
							// Add seclected Information to List of BangThongKe
								list.clear();
								MainQuanLy.setResultSet_NhanKhau();
								try {
									while (MainQuanLy.resultSet.next())
										if (value.equals(MainQuanLy.resultSet.getString("so_ho_khau_so_hk"))) addToList();
						
							// Create BangThongKe
								if (list.size()!=0) {
									setBangThongKe(e);
									kt_SoHoKhau=true;//Format is true;
								}
								else {
									Label warningLabel=new Label("No results found");
									warningLabel.setTextFill(Color.RED);
									gridPane.add(warningLabel,1,1);
								}
									
									MainQuanLy.resultSet.close();//close ResultSet
								} catch (SQLException e1) {
									e1.printStackTrace();
								}
							
						} else {
						// Warning - format is false
							Label warningLabel=new Label("Error! Please try again!");
							warningLabel.setTextFill(Color.RED);
							gridPane.add(warningLabel,1,1);
							}
					});
					if (result.isPresent()==false) break;// When press CANCEL-> exit the loop;
				}
			});
	}
	
// Action Button button_Back
	public void action_Button_Back() {
		button_Back.setOnAction(e->{
			Stage stage = (Stage)((Node) e.getSource()).getScene().getWindow();
	        FXMLLoader loader = new FXMLLoader();
	        loader.setLocation(getClass().getResource("menu.fxml"));
	        Parent sampleParent=null;
			try {
				sampleParent = loader.load();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	        Scene scene = new Scene(sampleParent);
	        stage.setScene(scene);
		});
	}
}