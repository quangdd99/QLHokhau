
package qlhokhauController;

import dao.TimKiemSoHoKhauDao;
import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.SoHoKhau;


public class HoKhauDetailController implements Initializable {

    @FXML
    private TableView<SoHoKhau> table;
    @FXML
    private TableColumn<SoHoKhau, Integer> id;
    @FXML
    private TableColumn<SoHoKhau, String> sohk;
    @FXML
    private TableColumn<SoHoKhau, String> sonha;
    @FXML
    private TableColumn<SoHoKhau, String> duong;
    @FXML
    private TableColumn<SoHoKhau, String> phuong;
    @FXML
    private TableColumn<SoHoKhau, Date> quan;
    @FXML
    private TableColumn<SoHoKhau, String> chuho;
    @FXML
    private TableColumn<SoHoKhau, String> tt;
    private ObservableList<SoHoKhau> hoKhauList;
    
    public void getHoKhauDetail(String key){
        TimKiemSoHoKhauDao soHoKhauDao = new TimKiemSoHoKhauDao();
        hoKhauList = FXCollections.observableArrayList(
                soHoKhauDao.getSHKById(key)
        );
        id.setCellValueFactory(new PropertyValueFactory<>("id"));
        sohk.setCellValueFactory(new PropertyValueFactory<>("soHk"));
        sonha.setCellValueFactory(new PropertyValueFactory<>("soNha"));
        duong.setCellValueFactory(new PropertyValueFactory<>("duongPho"));
        phuong.setCellValueFactory(new PropertyValueFactory<>("phuong"));
        chuho.setCellValueFactory(new PropertyValueFactory<>("chuHo"));
        tt.setCellValueFactory(new PropertyValueFactory<>("status"));
        quan.setCellValueFactory(new PropertyValueFactory<>("quan"));
        

        table.setItems(hoKhauList);
    }
    
    @FXML
    public void goBack(ActionEvent event) throws IOException {
        
        
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("SearchHoKhauChuyen.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);
        stage.setScene(scene);
    }
    @FXML
    public void detail(ActionEvent e) throws IOException {
        Stage stage = (Stage)((Node) e.getSource()).getScene().getWindow();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("ChiTietHoKhau.fxml"));
        Parent root = loader.load();        
        Scene scene = new Scene(root);
        ChiTietHoKhauController detail = loader.getController();
        String key = table.getSelectionModel().getSelectedItem().getSoHk();
        detail.getNhanKhauDetail(key);
        stage.setScene(scene);
        stage.show();;

    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
