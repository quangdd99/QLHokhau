package qlhokhauController;

import dao.NhatKyDAO;
import java.awt.Component;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import model.MainQuanLy;

import java.net.URL;
import java.util.ResourceBundle;
import javax.swing.JOptionPane;

public class AddNhanKhauController implements Initializable{

    @FXML
    private TextField id;
    @FXML
    private TextField ten;
    @FXML
    private TextField biDanh;
    @FXML
    private ChoiceBox<String> gioiTinh;
    @FXML
    private TextField qhch;
    @FXML
    private DatePicker ngaySinh;
    @FXML
    private TextField noiSinh;
    @FXML
    private TextField queQuan;
    @FXML
    private TextField danToc;
    @FXML
    private TextField ngheNghiep;
    @FXML
    private TextField noiLamViec;
    @FXML
    private TextField CMND;
    @FXML
    private DatePicker ngayCap;
    @FXML
    private TextField noiCap;
    @FXML
    private DatePicker ngayDangKi;
    @FXML
    private TextField diaChiTruoc;
    @FXML
    private TextField soHK;
    @FXML
    private TextField status;

    @FXML
    private void Add(){
        int i =0;
        try{
        String sql = "INSERT INTO `nhan_khau` VALUES ("+
                id.getText()+ ",'"+
                ten.getText()+ "','"+
                biDanh.getText()+"','"+
                gioiTinh.getValue().toString() + "','"+
                qhch.getText() + "','"+
                ngaySinh.getValue().toString() + "','"+
                noiSinh.getText() + "','"+
                queQuan.getText() + "','"+
                danToc.getText() + "','"+
                ngheNghiep.getText() + "','"+
                noiLamViec.getText() + "','"+
                CMND.getText() + "','"+
                ngayCap.getValue().toString() + "','"+
                noiCap.getText() + "','"+
                ngayDangKi.getValue().toString() + "','"+
                diaChiTruoc.getText() + "','"+
                soHK.getText() + "',"+
                status.getText() +");";
        String noiDung = "Thêm nhân khẩu số: "+id.getText() +" tên "+ten.getText()+"cmnd: "+CMND.getText()+" qua thao tác trực tiếp";
                NhatKyDAO k = new NhatKyDAO();
                k.addNhatKy(noiDung);
        
        MainQuanLy.statement.execute(sql);}
        catch(Exception e){
            Component frame = null;i=1;
            JOptionPane.showMessageDialog(frame ,"Failed! Please Add again");
        }
        if (i==0){          Component frame = null;
                            JOptionPane.showMessageDialog(frame ,"Completed ! Close form and Refresh to continue!");}
        }
    
    

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        ObservableList<String> gioiTinhs = FXCollections.observableArrayList("Nam", "Nữ");
        gioiTinh.setItems(gioiTinhs);
    }
}
