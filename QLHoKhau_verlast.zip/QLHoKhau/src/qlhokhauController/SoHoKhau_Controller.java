package qlhokhauController;

import java.io.IOException;
import java.time.LocalDate;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import model.NhanKhau;
/**
 * 
 * @Author: Lương Ngọc Thuyết
 * MSSV:20183994
 */
public class SoHoKhau_Controller{
	@FXML
	Button back_Button_SoHoKhau;
	
	@FXML
	TextField textField_QHCH;
	
	@FXML
	TextField textField_Name;
	
	@FXML
	TextField textField_NameOther;
	
	@FXML
	TextField textField_QueQuan;
	
	@FXML
	TextField textField_DanToc;
	
	@FXML
	TextField textField_TonGiao;
	
	@FXML
	TextField textField_CMND;
	
	@FXML
	TextField textField_NgheNghiep;
	
	@FXML
	TextField textField_NoiLamViec;
	
	@FXML
	TextArea textArea_NoiThuongTru_Before;
	
	@FXML
	DatePicker date_Birthday;
	
	@FXML
	DatePicker date_NgayChuyenDen;
	
	@FXML
	ChoiceBox<String> choiceBox_Gender;
	
	@FXML
	TextArea textArea_GhiChu;
	
	public void setSoHoKhau(NhanKhau nhankhau) {
			choiceBox_Gender.getItems().addAll("Nam","Nữ");
			textField_QHCH.setText(nhankhau.getQuanHeChuHo());
			textField_Name.setText(nhankhau.getTen());
			textField_NameOther.setText(nhankhau.getBiDanh());
			textField_QueQuan.setText(nhankhau.getQueQuan());
			textField_DanToc.setText(nhankhau.getDanToc());
			textField_TonGiao.setText("None");
			textField_CMND.setText(nhankhau.getCmnd());
			textField_NoiLamViec.setText(nhankhau.getNoiLamViec());
			textField_NgheNghiep.setText(nhankhau.getNgheNghiep());
			textArea_NoiThuongTru_Before.setText(nhankhau.getDiaChiTruoc());
			date_Birthday.setValue(LocalDate.parse(nhankhau.getNgaySinh().toString()));
			date_NgayChuyenDen.setValue(LocalDate.parse(nhankhau.getNgayDangKy().toString()));
			choiceBox_Gender.setValue(nhankhau.getGioiTinh());
	}
	public void setGhiChu(String s) {
		textArea_GhiChu.setText(s);
	}
	
	public void goBack_BangThongKe(ActionEvent e) throws IOException {
			Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
			if (BangThongKe_Controller.kt_SHK==true) 
				 stage.setScene(BangThongKe_Controller.scene_ThongKe_SHK);
			else
				stage.setScene(ThongKe_Controller.scene_BangThongKe);
			
			stage.setTitle("DANH SÁCH THỐNG KÊ");
			stage.setResizable(false);
	}
}
