
package qlhokhauController;

import dao.TimKiemNhanKhauDao;
import dao.TimKiemSinhConDao;
import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.NhanKhau;
import model.SinhCon;


public class ChiTietHoKhauController implements Initializable {

    @FXML
    private TableView<NhanKhau> table1;
    @FXML
    private TableColumn<NhanKhau, Integer> id;
    @FXML
    private TableColumn<NhanKhau, String> ten;
    @FXML
    private TableColumn<NhanKhau, String> bidanh;
    @FXML
    private TableColumn<NhanKhau, String> gioitinh;
    @FXML
    private TableColumn<NhanKhau, String> quanhe;
    @FXML
    private TableColumn<NhanKhau, Date> ngaysinh;
    @FXML
    private TableColumn<NhanKhau, String> noisinh;
    @FXML
    private TableColumn<NhanKhau, String> quequan;
    @FXML
    private TableColumn<NhanKhau, String> dantoc;
    @FXML
    private TableColumn<NhanKhau, String> nghenghiep;
    @FXML
    private TableColumn<NhanKhau, String> cmnd;
    @FXML
    private TableColumn<NhanKhau, String> ngaycap;
    @FXML
    private TableColumn<NhanKhau, String> noicap;
    @FXML
    private TableColumn<NhanKhau, String> sohk;
    @FXML
    private TableColumn<NhanKhau, String> tt;

    private ObservableList<NhanKhau> nhanKhauList;
    
    @FXML
    private TableView<SinhCon> table2;
    @FXML
    private TableColumn<SinhCon, Integer> id1;
    @FXML
    private TableColumn<SinhCon, String> ten1;
    @FXML
    private TableColumn<SinhCon, String> bidanh1;
    @FXML
    private TableColumn<SinhCon, String> gioitinh1;
    @FXML
    private TableColumn<SinhCon, String> quanhe1;
    @FXML
    private TableColumn<SinhCon, Date> ngaysinh1;
    @FXML
    private TableColumn<SinhCon, String> noisinh1;
    @FXML
    private TableColumn<SinhCon, String> quequan1;
    @FXML
    private TableColumn<SinhCon, String> dantoc1;
    @FXML
    private TableColumn<SinhCon, String> nghenghiep1;
    @FXML
    private TableColumn<SinhCon, String> cmnd1;
    @FXML
    private TableColumn<SinhCon, String> ngaycap1;
    @FXML
    private TableColumn<SinhCon, String> noicap1;
    @FXML
    private TableColumn<SinhCon, String> sohk1;
    @FXML
    private TableColumn<SinhCon, String> tt1;
    private ObservableList<SinhCon> sinhConList;
    
    public void getNhanKhauDetail(String key){
        TimKiemNhanKhauDao nhanKhauDao = new TimKiemNhanKhauDao();
        TimKiemSinhConDao sinhConDao = new TimKiemSinhConDao();
        nhanKhauList = FXCollections.observableArrayList(
                nhanKhauDao.getListNhanKhau(key)
        );
        sinhConList = FXCollections.observableArrayList(
                sinhConDao.getListSinhCon(key)
        );
        id.setCellValueFactory(new PropertyValueFactory<>("id"));
        ten.setCellValueFactory(new PropertyValueFactory<>("ten"));
        bidanh.setCellValueFactory(new PropertyValueFactory<>("biDanh"));
        gioitinh.setCellValueFactory(new PropertyValueFactory<>("gioiTinh"));
        quanhe.setCellValueFactory(new PropertyValueFactory<>("quanHeChuHo"));
        ngaysinh.setCellValueFactory(new PropertyValueFactory<>("ngaySinh"));
        noisinh.setCellValueFactory(new PropertyValueFactory<>("noiSinh"));
        quequan.setCellValueFactory(new PropertyValueFactory<>("queQuan"));
        dantoc.setCellValueFactory(new PropertyValueFactory<>("danToc"));
        nghenghiep.setCellValueFactory(new PropertyValueFactory<>("ngheNghiep"));
        cmnd.setCellValueFactory(new PropertyValueFactory<>("cmnd"));
        ngaycap.setCellValueFactory(new PropertyValueFactory<>("ngayCap"));
        noicap.setCellValueFactory(new PropertyValueFactory<>("noiCap"));
        sohk.setCellValueFactory(new PropertyValueFactory<>("soHk"));
        tt.setCellValueFactory(new PropertyValueFactory<>("status"));

        table1.setItems(nhanKhauList);
        
        id1.setCellValueFactory(new PropertyValueFactory<>("id"));
        ten1.setCellValueFactory(new PropertyValueFactory<>("ten"));
        bidanh1.setCellValueFactory(new PropertyValueFactory<>("biDanh"));
        gioitinh1.setCellValueFactory(new PropertyValueFactory<>("gioiTinh"));
        quanhe1.setCellValueFactory(new PropertyValueFactory<>("quanHeChuHo"));
        ngaysinh1.setCellValueFactory(new PropertyValueFactory<>("ngaySinh"));
        noisinh1.setCellValueFactory(new PropertyValueFactory<>("noiSinh"));
        quequan1.setCellValueFactory(new PropertyValueFactory<>("queQuan"));
        dantoc1.setCellValueFactory(new PropertyValueFactory<>("danToc"));
        nghenghiep1.setCellValueFactory(new PropertyValueFactory<>("ngheNghiep"));       
        cmnd1.setCellValueFactory(new PropertyValueFactory<>("cmnd"));
        ngaycap1.setCellValueFactory(new PropertyValueFactory<>("ngayCap"));
        noicap1.setCellValueFactory(new PropertyValueFactory<>("noiCap"));
        sohk1.setCellValueFactory(new PropertyValueFactory<>("soHk"));
        tt1.setCellValueFactory(new PropertyValueFactory<>("status"));
        
        table2.setItems(sinhConList);
        
        
    }
    
    @FXML
    public void goBack(ActionEvent event) throws IOException {
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("HoKhauDetail.fxml"));
        Parent sampleParent = loader.load();
        Scene scene = new Scene(sampleParent);
        stage.setScene(scene);
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
