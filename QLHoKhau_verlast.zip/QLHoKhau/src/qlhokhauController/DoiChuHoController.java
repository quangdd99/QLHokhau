/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package qlhokhauController;

import dao.CheckNhanKhauDAO;
import dao.DoiChuHoDAO;
import dao.ThongBaoDAO;
import dao.NhatKyDAO;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author hohun
 */
public class DoiChuHoController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    TextField shk;
    
    @FXML
    TextField chuCu;
    
    @FXML
    TextField chuMoi;
    
    @FXML
    TextField cmndCu;
    
    @FXML
    TextField cmndMoi;
    
    @FXML
    TextField quanHe;
    
    @FXML
    Label thongBao;
    
    @FXML
    private void actionSuaDoi(ActionEvent event) throws IOException {
        
        String sohk = shk.getText();
        String cCu = chuCu.getText();
        String cMoi = chuMoi.getText();
        String cmCu = cmndCu.getText();
        String cmMoi = cmndMoi.getText();
        String qh = quanHe.getText();
        ThongBaoDAO e = new ThongBaoDAO();
        
        
        if ("".equals(sohk) || "".equals(cCu) || "".equals(cMoi) || "".equals(cmCu) || "".equals(cmMoi) || "".equals(qh)){
            e.showErrorText("Thông tin còn thiếu!");
        }
        else{
            DoiChuHoDAO doi = new DoiChuHoDAO();
            CheckNhanKhauDAO ck = new CheckNhanKhauDAO();
        if (!doi.check(sohk, cmCu) || !doi.check(sohk,cmMoi) || !ck.check(cCu, cmCu) || !ck.check(cMoi, cmMoi)){
            e.showErrorText("Thông tin không đúng!");
            
        }
        else{
            doi.doiChu(cmCu, qh);
            doi.doiChu(cmMoi, "Chủ hộ");
            doi.doiSoHK(sohk, cMoi);
            String noiDung = "Đổi chủ hộ: Số hộ khẩu "+sohk+" từ "+cCu+" (cmnd "+cmCu+") sang "+cMoi+" (cmnd "+cmMoi +"). Quan hệ chủ hộ cũ và chủ hộ mới: "+qh ;
            NhatKyDAO k = new NhatKyDAO();
            k.addNhatKy(noiDung);
            e.showSuccessText("Thay đổi thành công!");
            shk.clear();
            chuCu.clear();
            chuMoi.clear();
            cmndCu.clear();
            cmndMoi.clear();
            quanHe.clear();
        }  
        }
    }
    @FXML
    private void actionQuayLai(ActionEvent event) throws IOException {
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("Sua.fxml"));
        Parent sampleParent = loader.load();
        Scene scene = new Scene(sampleParent);
        stage.setScene(scene);
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
