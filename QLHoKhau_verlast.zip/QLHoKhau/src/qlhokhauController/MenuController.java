/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package qlhokhauController;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;
import model.MainQuanLy;

/**
 * FXML Controller class
 *
 * @author hohun
 */
public class MenuController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private TextField viewUserName;
    @FXML
    private TextArea inforText;
    
    
    @FXML
    public void handleButtonSignOut(ActionEvent event) throws IOException{
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("SignIn.fxml"));
        Parent sampleParent = loader.load();
        Scene scene = new Scene(sampleParent);
        stage.setScene(scene);
    }
    
    @FXML
    public void handleButtonTimKiem(ActionEvent event) throws IOException{
        
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("Search.fxml"));
        Parent sampleParent = loader.load();
        Scene scene = new Scene(sampleParent);
        stage.setScene(scene);       
        
    }
    @FXML
    public void handleButtonThongKe(ActionEvent event) throws IOException {
    	 Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
         FXMLLoader loader = new FXMLLoader();
         loader.setLocation(getClass().getResource("ThongKe.fxml"));
         Parent sampleParent = loader.load();
         Scene scene = new Scene(sampleParent);
         MainQuanLy.scene_ThongKe=scene; 
         stage.setScene(scene);    
         stage.setTitle("THỐNG KÊ");
         stage.setResizable(false);
    }
    @FXML
    public void handleButtonLichSu(ActionEvent event){
    	Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("nhatKiThayDoi.fxml"));
        Parent sampleParent=null;
		try {
			sampleParent = loader.load();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        Scene scene = new Scene(sampleParent);
        stage.setScene(scene);       
    }
    @FXML
    public void handleButtonThemNK(ActionEvent event) {
    	Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("nhanKhau.fxml"));
        Parent sampleParent=null;
		try {
			sampleParent = loader.load();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        Scene scene = new Scene(sampleParent);
        stage.setScene(scene); 
    }
    @FXML
    public void handleButtonThemHK(ActionEvent event){
    	 Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
         FXMLLoader loader = new FXMLLoader();
         loader.setLocation(getClass().getResource("SoHoKhau2.fxml"));
         Parent sampleParent=null;
		try {
			sampleParent = loader.load();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
         Scene scene = new Scene(sampleParent);
         stage.setScene(scene);       
    }
    @FXML
    public void handleButtonSua(ActionEvent event) throws IOException{
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("Sua.fxml"));
        Parent sampleParent = loader.load();
        Scene scene = new Scene(sampleParent);
        stage.setTitle("Sửa");
        stage.setScene(scene);
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        viewUserName.setText("Admin");
        inforText.setText("Ứng dụng quản lý hộ khẩu được cập nhật mới nhất ngày 11/12/2019. Sản phẩm được xây dựng và phát triển bởi nhóm 4. Mọi thông tin chi tiết, phản hồi liên hệ tới gmail.....");
        // TODO
    }    
    
}
