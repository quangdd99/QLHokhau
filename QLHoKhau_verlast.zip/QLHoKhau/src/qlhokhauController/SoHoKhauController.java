package qlhokhauController;

import dao.NhatKyDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.MainQuanLy;
import model.SoHoKhau;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class SoHoKhauController implements Initializable {
    @FXML
    private TableView<SoHoKhau> table;

    @FXML
    private TableColumn<SoHoKhau, Integer> idColumn;
    @FXML
    private TableColumn<SoHoKhau, String> soHKColumn;
    @FXML
    private TableColumn<SoHoKhau, String> chuHoColumn;
    @FXML
    private TableColumn<SoHoKhau, String> soNhaColumn;
    @FXML
    private TableColumn<SoHoKhau, String> duongPhoColumn;
    @FXML
    private TableColumn<SoHoKhau, String> phuongColumn;
    @FXML
    private TableColumn<SoHoKhau, String> quanColumn;
    @FXML
    private TableColumn<SoHoKhau, Integer> statusColumn;

    private ObservableList<SoHoKhau> soHoKhauList;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        soHoKhauList = FXCollections.observableArrayList();

        try {
            ShowSoHoKhau();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        idColumn.setCellValueFactory(new PropertyValueFactory<SoHoKhau, Integer>("id"));
        soHKColumn.setCellValueFactory(new PropertyValueFactory<SoHoKhau, String>("soHk"));
        chuHoColumn.setCellValueFactory(new PropertyValueFactory<SoHoKhau, String>("chuHo"));
        soNhaColumn.setCellValueFactory(new PropertyValueFactory<SoHoKhau, String>("soNha"));
        duongPhoColumn.setCellValueFactory(new PropertyValueFactory<SoHoKhau, String>("duongPho"));
        phuongColumn.setCellValueFactory(new PropertyValueFactory<SoHoKhau, String>("phuong"));
        quanColumn.setCellValueFactory(new PropertyValueFactory<SoHoKhau, String>("quan"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<SoHoKhau, Integer>("status"));

        table.setItems(soHoKhauList);
    }

    @FXML
    private void addSoHoKhau() throws IOException, SQLException {

        Parent secondaryLayout = FXMLLoader.load(getClass().getResource("addSoHoKhau.fxml"));
        Scene secondScene = new Scene(secondaryLayout);
        Stage newWindow = new Stage();
        newWindow.setTitle("Thêm hộ khẩu");
        newWindow.setScene(secondScene);
        newWindow.setResizable(false);
   
        // Chỉ định modality (thể thức) cho cửa sổ mới.
        newWindow.initModality(Modality.NONE);

        // Chỉ định chủ sở hữu (cửa sổ cha) của cửa sổ mới.
        newWindow.initOwner(QLHoKhau.primaryStage);

        // Sét đặt vị trí cho cửa sổ thứ 2.
        // Có vị trí tương đối đối với cửa sổ chính.
        newWindow.setX(QLHoKhau.primaryStage.getX() + 10);
        newWindow.setY(QLHoKhau.primaryStage.getY() + 10);

        newWindow.show();
    }

    @FXML
    private void xoaSoHoKhau() throws SQLException {
        int deletedId = table.getSelectionModel().getSelectedItem().getId();
         ResultSet resultSet = MainQuanLy.statement.executeQuery("SELECT * FROM `so_ho_khau` where id="+deletedId+";");
        while(resultSet.next()){
            int id = resultSet.getInt("id");
            String so_hk = resultSet.getString("so_hk");
            String chu_ho = resultSet.getString("chu_ho");
            String so_nha = resultSet.getString("so_nha");
            String duong_pho = resultSet.getString("duong_pho");
            String phuong = resultSet.getString("phuong");
            String quan = resultSet.getString("quan");
            int status = resultSet.getInt("status");
            
                String noiDung = "Xóa hộ khẩu số: "+ id +" số hộ khẩu: "+so_hk+ " qua thao tác trực tiếp";
                NhatKyDAO k = new NhatKyDAO();
                k.addNhatKy(noiDung);
        }
        
        MainQuanLy.statement.executeUpdate("DELETE FROM `so_ho_khau` WHERE id = " + deletedId + ";");
        ShowSoHoKhau();
    }


    @FXML
    private void ShowSoHoKhau() throws SQLException {
        ResultSet resultSet = MainQuanLy.statement.executeQuery("SELECT * FROM `so_ho_khau`;");
        soHoKhauList.clear();
        while (resultSet.next()){
            int id = resultSet.getInt("id");
            String so_hk = resultSet.getString("so_hk");
            String chu_ho = resultSet.getString("chu_ho");
            String so_nha = resultSet.getString("so_nha");
            String duong_pho = resultSet.getString("duong_pho");
            String phuong = resultSet.getString("phuong");
            String quan = resultSet.getString("quan");
            int status = resultSet.getInt("status");
            soHoKhauList.add(new SoHoKhau(id, so_hk, chu_ho, so_nha, duong_pho, phuong, quan, status));
        }
    }

    @FXML
    private void backToHome() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("menu.fxml"));
        QLHoKhau.primaryStage.setTitle("Quản lí hộ khẩu");
        QLHoKhau.primaryStage.setScene(new Scene(root));
        QLHoKhau.primaryStage.show();
    }
}
