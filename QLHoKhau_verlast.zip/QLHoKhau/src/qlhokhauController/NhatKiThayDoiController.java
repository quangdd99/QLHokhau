package qlhokhauController;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import model.MainQuanLy;
import model.NhatKiThayDoi;

import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class NhatKiThayDoiController implements Initializable {

    @FXML
    TextField year;
    @FXML
    ChoiceBox<String> month;

    @FXML
    TableView<NhatKiThayDoi> table;
    @FXML
    TableColumn<NhatKiThayDoi, Integer> sttColumn;
    @FXML
    TableColumn<NhatKiThayDoi, Date> thoiGianColumn;
    @FXML
    TableColumn<NhatKiThayDoi, String> noiDungColumn;

    ObservableList<NhatKiThayDoi> nhatKiThayDoiList;
    
    private void ShowTheoNam(int year) throws SQLException {
        ResultSet resultSet = MainQuanLy.statement.executeQuery("SELECT * FROM nhat_ky_thay_doi WHERE (EXTRACT(YEAR FROM thoi_gian) = "+ year +");");
        nhatKiThayDoiList.clear();
        while (resultSet.next()){
            int stt = resultSet.getInt("stt");
            Date thoiGian = resultSet.getDate("thoi_gian");
            String noiDung = resultSet.getString("noi_dung");

            nhatKiThayDoiList.add(new NhatKiThayDoi(stt, thoiGian, noiDung));
        }
    }
    private void ShowTheoThang(int year, int month) throws SQLException {
        ResultSet resultSet = MainQuanLy.statement.executeQuery("SELECT * FROM nhat_ky_thay_doi WHERE (EXTRACT(YEAR FROM thoi_gian) = " + year + ") AND (EXTRACT(MONTH FROM thoi_gian) = "+month+");");
        nhatKiThayDoiList.clear();
        while (resultSet.next()){
            int stt = resultSet.getInt("stt");
            Date thoiGian = resultSet.getDate("thoi_gian");
            String noiDung = resultSet.getString("noi_dung");
            
            nhatKiThayDoiList.add(new NhatKiThayDoi(stt, thoiGian, noiDung));
        }
    }
 
    @FXML
    private void backToHome() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("menu.fxml"));
        QLHoKhau.primaryStage.setTitle("Quản lí hộ khẩu");
        QLHoKhau.primaryStage.setScene(new Scene(root));
        QLHoKhau.primaryStage.show();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        ObservableList<String> months = FXCollections.observableArrayList(
                "Cả năm", "Tháng 1", "Tháng 2", "Tháng 3", "Tháng 4", "Tháng 5", "Tháng 6",
                "Tháng 7", "Tháng 8", "Tháng 9", "Tháng 10", "Tháng 11", "Tháng 12");

        month.setItems(months);

        month.getSelectionModel().selectedIndexProperty().addListener((observable, oldValue, newValue) -> {
            int chosenIndex = newValue.intValue();
            int y = Integer.parseInt(year.getText());
            if(chosenIndex == 0){
                try {
                    ShowTheoNam(y);
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            else{
                try {
                    ShowTheoThang(y, chosenIndex);
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        });

        nhatKiThayDoiList = FXCollections.observableArrayList();

        sttColumn.setCellValueFactory(new PropertyValueFactory<>("stt"));
        thoiGianColumn.setCellValueFactory(new PropertyValueFactory<>("thoiGian"));
        noiDungColumn.setCellValueFactory(new PropertyValueFactory<>("noiDung"));

        table.setItems(nhatKiThayDoiList);
    }
}
